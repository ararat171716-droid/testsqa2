import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Clock,
  Droplets,
  Sprout,
  Thermometer,
  TrendingUp,
  Zap,
} from "lucide-react";
import { useApp } from "../AppContext";
import { AUTHOR, THESIS, GREENHOUSES, PHASE_LABELS, ECONOMICS, KPIS } from "../data";
import { StatusBar, StatusDot, Tag } from "../components/ui";
import { Logo } from "../components/Logo";
import { cn } from "../utils/cn";

// ============================================================
// СВОДНЫЙ ЭКРАН ДЛЯ ЗАЩИТЫ ДИПЛОМА
// Один экран «продаёт» приложение комиссии за 10 секунд:
// логотип, KPI, три теплицы и экономический эффект.
// ============================================================

export function SummaryScreen() {
  const { back, reset } = useApp();
  const top3 = GREENHOUSES.slice(0, 3);

  return (
    <div className="flex h-full flex-col bg-bg">
      {/* Герой-блок с логотипом и статусом */}
      <div className="relative shrink-0 bg-gradient-to-br from-brand via-brand to-brand-dark pb-8">
        <StatusBar tone="light" />
        <div className="absolute -right-12 -top-8 h-44 w-44 rounded-full bg-amber/20 blur-3xl" />

        <div className="relative px-5">
          <button
            onClick={back}
            className="mb-2 text-xs font-semibold text-white/70 transition hover:text-white"
          >
            ‹ Назад
          </button>
          <div className="flex items-center gap-3">
            <Logo size="lg" />
            <div>
              <h1 className="text-xl font-extrabold leading-tight text-white">
                АгроТеплица<span className="text-amber-light">.Контроль</span>
              </h1>
              <p className="text-[12px] text-white/80">Умная теплица в вашем кармане</p>
            </div>
          </div>

          <div className="mt-4 flex items-center gap-2.5 rounded-2xl bg-white/12 px-3.5 py-2.5 backdrop-blur-md">
            <AlertTriangle className="h-5 w-5 text-amber" />
            <div className="flex-1">
              <p className="text-[13px] font-bold text-white">1 теплица требует внимания</p>
              <p className="text-[11px] text-white/75">остальные системы — в норме</p>
            </div>
            <StatusDot status="warning" />
          </div>
        </div>
      </div>

      <main className="flex-1 overflow-y-auto thin-scroll px-4 pb-6">
        {/* Главный KPI — экономический эффект */}
        <div className="-mt-2 rounded-3xl bg-gradient-to-br from-amber to-amber-light p-4 shadow-soft">
          <div className="flex items-end justify-between">
            <div>
              <p className="text-[11px] font-bold uppercase tracking-wide text-[#0F1B12]/70">
                Экономический эффект
              </p>
              <p className="mt-1 text-3xl font-extrabold leading-none text-[#0F1B12]">
                {ECONOMICS.effect}
                <span className="ml-1 text-sm">тыс. ₽/год</span>
              </p>
            </div>
            <TrendingUp className="h-9 w-9 text-[#0F1B12]/80" strokeWidth={2} />
          </div>
          {/* Стacked-бар структуры эффекта */}
          <div className="mt-3 flex h-3 overflow-hidden rounded-full">
            <div className="bg-[#0F1B12]" style={{ width: "42%" }} />
            <div className="bg-[#0F1B12]/55" style={{ width: "58%" }} />
          </div>
          <div className="mt-1.5 flex justify-between text-[10px] font-semibold text-[#0F1B12]/80">
            <span>Время 210K</span>
            <span>Снижение потерь 290K</span>
          </div>
        </div>

        {/* Сетка KPI */}
        <div className="mt-3 grid grid-cols-4 gap-2">
          <KpiMini icon={Clock} value="72" unit="мин" label="время/день" />
          <KpiMini icon={Droplets} value={`${KPIS.waterSave}`} unit="%" label="вода" />
          <KpiMini icon={Zap} value={`${KPIS.energySave}`} unit="%" label="э/э" />
          <KpiMini icon={Sprout} value={`${KPIS.yield}`} unit="кг" label="урож./м²" />
        </div>

        {/* Три теплицы */}
        <div className="mb-2 mt-5 flex items-center justify-between px-1">
          <h2 className="text-[15px] font-bold text-tx">Теплицы комплекса</h2>
          <span className="text-[11px] text-tx-muted">3 объекта · онлайн</span>
        </div>
        <div className="space-y-2">
          {top3.map((g) => {
            const ok = g.status === "ok";
            return (
              <div
                key={g.id}
                className="flex items-center gap-3 rounded-2xl border border-line bg-surface p-3 shadow-card"
              >
                <div
                  className={cn(
                    "flex h-10 w-10 items-center justify-center rounded-xl",
                    ok ? "bg-brand/12" : "bg-amber/15"
                  )}
                >
                  {ok ? <CheckCircle2 className="h-5 w-5 text-brand" /> : <AlertTriangle className="h-5 w-5 text-amber" />}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px] font-bold text-tx">{g.name}</p>
                  <p className="truncate text-[11px] text-tx-sec">{g.culture}</p>
                </div>
                <Tag tone="green">{PHASE_LABELS[g.phase]}</Tag>
                <div className="flex items-center gap-1 pl-1">
                  <Thermometer className="h-3.5 w-3.5 text-tx-muted" />
                  <span className="text-[13px] font-extrabold text-tx">{g.temp}°</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Окупаемость */}
        <div className="mt-3 grid grid-cols-2 gap-2">
          <div className="rounded-2xl border border-line bg-surface p-3 text-center shadow-card">
            <p className="text-2xl font-extrabold text-brand">{ECONOMICS.payback}</p>
            <p className="text-[11px] text-tx-sec">года · окупаемость</p>
          </div>
          <div className="rounded-2xl border border-line bg-surface p-3 text-center shadow-card">
            <p className="text-2xl font-extrabold text-tx">{ECONOMICS.investment}</p>
            <p className="text-[11px] text-tx-sec">тыс. ₽ · внедрение</p>
          </div>
        </div>

        {/* CTA */}
        <button
          onClick={() => reset("dashboard")}
          className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-brand py-4 text-[15px] font-bold text-white shadow-soft transition hover:bg-brand-dark active:scale-[0.98]"
        >
          Открыть приложение
          <ArrowRight className="h-5 w-5" />
        </button>

        <div className="mt-3 rounded-2xl border border-line bg-surface-2 p-3 text-center">
          <p className="text-[12px] font-bold text-tx">{AUTHOR.name}</p>
          <p className="text-[10px] text-tx-sec">
            {AUTHOR.course}, {AUTHOR.university}
          </p>
          <p className="mt-1.5 text-[10px] leading-snug text-tx-muted">{THESIS.short}</p>
        </div>

        <p className="mt-3 text-center text-[11px] text-tx-muted">
          Трёхуровневая IoT-архитектура · УНПК «Агроцентр» · АО «Совхоз-Весна»
        </p>
      </main>
    </div>
  );
}

function KpiMini({
  icon: Icon,
  value,
  unit,
  label,
}: {
  icon: typeof Clock;
  value: string;
  unit: string;
  label: string;
}) {
  return (
    <div className="flex flex-col items-center gap-1 rounded-2xl border border-line bg-surface p-2.5 text-center shadow-card">
      <Icon className="h-4 w-4 text-brand" />
      <div className="flex items-baseline gap-0.5">
        <span className="text-base font-extrabold leading-none text-tx">{value}</span>
        <span className="text-[9px] font-semibold text-tx-sec">{unit}</span>
      </div>
      <span className="text-[9px] leading-tight text-tx-muted">{label}</span>
    </div>
  );
}
