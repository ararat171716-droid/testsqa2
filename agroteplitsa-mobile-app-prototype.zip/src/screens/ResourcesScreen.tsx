import { useState } from "react";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import {
  Droplets,
  FlaskConical,
  Package,
  Plus,
  TrendingDown,
  Zap,
  Check,
} from "lucide-react";
import { FERTILIZER_LOG, STOCK, WATER_SPLIT } from "../data";
import {
  BackHeader,
  BottomNav,
  Card,
  ProgressBar,
  Sheet,
  StatusBar,
  Tag,
} from "../components/ui";
import { cn } from "../utils/cn";

// ============================================================
// Экран 5 · УЧЁТ И КОНТРОЛЬ РЕСУРСОВ
// Расход воды и электроэнергии, журнал удобрений, остатки на
// складе, форма фиксации внесения.
// ============================================================

export function ResourcesScreen() {
  const [log, setLog] = useState(FERTILIZER_LOG);
  const [sheet, setSheet] = useState(false);

  return (
    <div className="flex h-full flex-col bg-bg">
      <StatusBar />
      <BackHeader title="Ресурсы" subtitle="Учёт и контроль" />

      <main className="flex-1 overflow-y-auto thin-scroll px-4 pb-28">
        {/* --- Расход воды --- */}
        <Card className="p-4">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-500/12">
                <Droplets className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <h3 className="text-[15px] font-bold text-tx">Расход воды</h3>
                <p className="text-[11px] text-tx-sec">за сегодня</p>
              </div>
            </div>
            <span className="text-2xl font-extrabold text-tx">
              8,4<span className="ml-1 text-sm font-semibold text-tx-sec">м³</span>
            </span>
          </div>

          {/* Круговая диаграмма структуры расхода */}
          <div className="mt-3 flex items-center gap-3 rounded-2xl bg-surface-2 p-3">
            <div className="h-[90px] w-[90px] shrink-0">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={WATER_SPLIT}
                    dataKey="value"
                    innerRadius={26}
                    outerRadius={42}
                    paddingAngle={2}
                    stroke="none"
                  >
                    {WATER_SPLIT.map((e) => (
                      <Cell key={e.name} fill={e.color} />
                    ))}
                  </Pie>
                  <Tooltip content={<PieTip unit="%" />} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex-1 space-y-1.5">
              {WATER_SPLIT.map((e) => (
                <div key={e.name} className="flex items-center gap-2">
                  <span className="h-2.5 w-2.5 rounded-full" style={{ background: e.color }} />
                  <span className="flex-1 truncate text-[11px] text-tx-sec">{e.name}</span>
                  <span className="text-[11px] font-bold text-tx">{e.value}%</span>
                </div>
              ))}
            </div>
          </div>

          {/* Прогресс к плану за месяц */}
          <div className="mt-3">
            <div className="mb-1.5 flex items-center justify-between text-xs">
              <span className="text-tx-sec">План на месяц: 246 / 300 м³</span>
              <span className="font-bold text-blue-500">82%</span>
            </div>
            <ProgressBar value={82} barClassName="bg-blue-500" />
          </div>
        </Card>

        {/* --- Расход электроэнергии --- */}
        <Card className="mt-3 p-4">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber/15">
                <Zap className="h-5 w-5 text-amber" />
              </div>
              <div>
                <h3 className="text-[15px] font-bold text-tx">Электроэнергия</h3>
                <p className="text-[11px] text-tx-sec">за месяц</p>
              </div>
            </div>
            <Tag tone="green">
              <TrendingDown className="h-3 w-3" /> −12%
            </Tag>
          </div>
          <div className="mt-3 flex items-end justify-between rounded-2xl bg-surface-2 p-3">
            <div>
              <p className="text-2xl font-extrabold text-tx">
                4 180<span className="ml-1 text-sm font-semibold text-tx-sec">кВт·ч</span>
              </p>
              <p className="text-[11px] text-tx-sec">объём потребления</p>
            </div>
            <div className="text-right">
              <p className="text-xl font-extrabold text-tx">18 392 ₽</p>
              <p className="text-[11px] text-tx-sec">стоимость</p>
            </div>
          </div>
        </Card>

        {/* --- Остатки на складе --- */}
        <div className="mb-2 mt-5 flex items-center gap-2">
          <Package className="h-4 w-4 text-tx-sec" />
          <h2 className="text-[15px] font-bold text-tx">Остатки на складе</h2>
        </div>
        <div className="space-y-2">
          {STOCK.map((s) => {
            const pct = (s.balance / s.capacity) * 100;
            return (
              <Card key={s.id} className="p-3.5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-semibold text-tx">{s.name}</p>
                    <p className="text-[11px] text-tx-sec">{s.type}</p>
                  </div>
                  {s.low && (
                    <Tag tone="red">
                      <span className="h-1.5 w-1.5 rounded-full bg-red-500" /> Низкий запас
                    </Tag>
                  )}
                </div>
                <div className="mt-2.5">
                  <div className="mb-1 flex items-center justify-between text-[11px]">
                    <span className="font-semibold text-tx">
                      {s.balance} / {s.capacity} кг
                    </span>
                    <span className={cn("font-bold", s.low ? "text-red-500" : "text-brand")}>
                      {Math.round(pct)}%
                    </span>
                  </div>
                  <ProgressBar
                    value={pct}
                    barClassName={s.low ? "bg-red-500" : "bg-brand"}
                  />
                </div>
              </Card>
            );
          })}
        </div>

        {/* --- Журнал внесения удобрений --- */}
        <div className="mb-2 mt-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FlaskConical className="h-4 w-4 text-tx-sec" />
            <h2 className="text-[15px] font-bold text-tx">Журнал внесения</h2>
          </div>
          <span className="text-xs font-semibold text-tx-muted">{log.length} записей</span>
        </div>

        {/* Шапка таблицы */}
        <Card className="overflow-hidden">
          <div className="grid grid-cols-12 gap-1 border-b border-line bg-surface-2 px-3 py-2 text-[10px] font-bold uppercase tracking-wide text-tx-muted">
            <span className="col-span-3">Дата</span>
            <span className="col-span-5">Удобрение</span>
            <span className="col-span-4 text-right">Доза</span>
          </div>
          {log.map((r) => (
            <div
              key={r.id}
              className="grid grid-cols-12 gap-1 border-b border-line px-3 py-2.5 last:border-0"
            >
              <div className="col-span-3">
                <p className="text-xs font-bold text-tx">{r.date.slice(0, 5)}</p>
                <p className="text-[10px] text-tx-sec">{r.culture.split(" ")[0]}</p>
              </div>
              <div className="col-span-5">
                <p className="truncate text-xs font-semibold text-tx">{r.type}</p>
                <p className="truncate text-[10px] text-tx-muted">{r.responsible}</p>
              </div>
              <div className="col-span-4 text-right">
                <p className="text-xs font-bold text-brand">{r.dose.split(" ")[0]}</p>
                <p className="text-[10px] text-tx-sec">кг/100м²</p>
              </div>
            </div>
          ))}
        </Card>

        {/* --- Кнопка фиксации --- */}
        <button
          onClick={() => setSheet(true)}
          className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl bg-brand py-4 text-[15px] font-bold text-white shadow-soft transition hover:bg-brand-dark active:scale-[0.98]"
        >
          <Plus className="h-5 w-5" />
          Зафиксировать внесение
        </button>
      </main>

      {/* --- Форма внесения (нижний sheet) --- */}
      <RecordSheet
        open={sheet}
        onClose={() => setSheet(false)}
        onSubmit={(rec) => {
          setLog((l) => [rec, ...l]);
          setSheet(false);
        }}
      />

      <BottomNav />
    </div>
  );
}

// ---- Тултип круговой диаграммы ----
function PieTip({ active, payload, unit }: any) {
  if (!active || !payload?.length) return null;
  const p = payload[0];
  return (
    <div className="rounded-xl border border-line bg-surface px-3 py-1.5 shadow-soft">
      <p className="text-xs font-bold text-tx">{p.name}</p>
      <p className="text-xs font-semibold text-brand">
        {p.value} {unit}
      </p>
    </div>
  );
}

// ---- Форма фиксации внесения удобрений ----
function RecordSheet({
  open,
  onClose,
  onSubmit,
}: {
  open: boolean;
  onClose: () => void;
  onSubmit: (rec: FertilizerRecordLike) => void;
}) {
  const [culture, setCulture] = useState("Огурец «Кураж F1»");
  const [type, setType] = useState("Аммиачная селитра (N)");
  const [dose, setDose] = useState("2,0");
  const today = new Date().toLocaleDateString("ru-RU");

  return (
    <Sheet open={open} onClose={onClose}>
      <div className="px-5 pb-2">
        <h2 className="text-lg font-bold text-tx">Внесение удобрения</h2>
        <p className="text-xs text-tx-sec">Заполните данные операции</p>
      </div>
      <div className="space-y-3 px-5">
        <FormField label="Дата">
          <input value={today} readOnly className="w-full bg-transparent text-sm font-medium text-tx outline-none" />
        </FormField>
        <FormField label="Культура">
          <select
            value={culture}
            onChange={(e) => setCulture(e.target.value)}
            className="w-full bg-transparent text-sm font-medium text-tx outline-none"
          >
            <option>Огурец «Кураж F1»</option>
            <option>Томат «Малиновый Гигант»</option>
            <option>Перец «Атлант»</option>
          </select>
        </FormField>
        <FormField label="Тип удобрения">
          <input
            value={type}
            onChange={(e) => setType(e.target.value)}
            className="w-full bg-transparent text-sm font-medium text-tx outline-none"
          />
        </FormField>
        <FormField label="Доза, кг / 100 м²">
          <input
            value={dose}
            onChange={(e) => setDose(e.target.value)}
            className="w-full bg-transparent text-sm font-medium text-tx outline-none"
          />
        </FormField>
        <FormField label="Ответственный">
          <input defaultValue="И.П. Соколов" className="w-full bg-transparent text-sm font-medium text-tx outline-none" />
        </FormField>
      </div>
      <div className="mt-5 px-5">
        <button
          onClick={() =>
            onSubmit({
              id: `f${Date.now()}`,
              date: today,
              culture,
              type,
              dose: `${dose} кг / 100 м²`,
              responsible: "И.П. Соколов",
            })
          }
          className="flex w-full items-center justify-center gap-2 rounded-2xl bg-brand py-4 text-[15px] font-bold text-white shadow-soft transition active:scale-[0.98]"
        >
          <Check className="h-5 w-5" />
          Сохранить запись
        </button>
      </div>
    </Sheet>
  );
}

function FormField({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-line bg-surface px-4 py-2.5">
      <span className="text-[11px] font-semibold uppercase tracking-wide text-tx-muted">{label}</span>
      <div className="mt-0.5">{children}</div>
    </div>
  );
}

// Локальный тип записи для формы
type FertilizerRecordLike = {
  id: string;
  date: string;
  culture: string;
  type: string;
  dose: string;
  responsible: string;
};
