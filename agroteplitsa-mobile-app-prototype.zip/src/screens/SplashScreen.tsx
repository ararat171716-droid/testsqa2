import { useEffect, useRef } from "react";
import { Logo } from "../components/Logo";
import { useApp } from "../AppContext";

// ============================================================
// Экран 0 · SPLASH-SCREEN
// Логотип «лист + Wi-Fi», название, слоган.
// Автопереход к онбордингу через ~2,6 с (или по тапу).
// ============================================================
export function SplashScreen() {
  const { replace } = useApp();
  const started = useRef(false);

  useEffect(() => {
    if (started.current) return;
    started.current = true;
    const t = setTimeout(() => replace("onboarding"), 2600);
    return () => clearTimeout(t);
  }, [replace]);

  return (
    // Полноэкранный агрозелёный градиент с декоративными бликами
    <button
      onClick={() => replace("onboarding")}
      className="relative h-full w-full overflow-hidden bg-gradient-to-b from-brand-light via-brand to-brand-dark"
    >
      {/* Декоративные размытые круги */}
      <div className="absolute -left-16 top-24 h-56 w-56 rounded-full bg-amber/30 blur-3xl" />
      <div className="absolute -right-20 bottom-32 h-64 w-64 rounded-full bg-white/10 blur-3xl" />

      {/* Контент по центру */}
      <div className="relative flex h-full flex-col items-center justify-center px-8">
        <div className="animate-scale-in flex flex-col items-center">
          <Logo size="xl" className="mb-7" />
          <h1 className="text-center text-[26px] font-extrabold leading-tight tracking-tight text-white">
            АгроТеплица
            <span className="block text-amber-light">.Контроль</span>
          </h1>
          <p className="mt-4 text-center text-[15px] font-medium text-white/80">
            Умная теплица в вашем кармане
          </p>
        </div>
      </div>

      {/* Индикатор загрузки внизу */}
      <div className="absolute bottom-16 left-0 right-0 flex flex-col items-center gap-2.5">
        <div className="h-1 w-32 overflow-hidden rounded-full bg-white/20">
          <div className="h-full w-1/2 animate-pulse rounded-full bg-amber" />
        </div>
        <span className="text-xs font-medium text-white/60">
          УНПК «Агроцентр» · АО «Совхоз-Весна»
        </span>
      </div>
    </button>
  );
}
