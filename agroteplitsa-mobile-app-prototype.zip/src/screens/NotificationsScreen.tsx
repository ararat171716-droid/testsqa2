import { useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  Bell,
  CheckCheck,
  Clock,
  Info,
  type LucideIcon,
} from "lucide-react";
import { useApp } from "../AppContext";
import { BackHeader, BottomNav, StatusBar } from "../components/ui";
import { cn } from "../utils/cn";
import type { NotifyType } from "../types";

// ============================================================
// Экран 7 · ОПОВЕЩЕНИЯ (Push-центр)
// Лента трёх типов: критические / предупреждения / информационные.
// Фильтры по типам, свайп для отметки «прочитано».
// ============================================================

const TYPE_META: Record<
  NotifyType,
  { icon: LucideIcon; bg: string; fg: string; label: string }
> = {
  critical: { icon: AlertTriangle, bg: "bg-red-500/12", fg: "text-red-500", label: "Критическое" },
  warning: { icon: Clock, bg: "bg-amber/15", fg: "text-amber", label: "Предупреждение" },
  info: { icon: Info, bg: "bg-blue-500/12", fg: "text-blue-500", label: "Информация" },
};

type Filter = "all" | NotifyType;

export function NotificationsScreen() {
  const { notifications, markRead, markAllRead, unreadCount } = useApp();
  const [filter, setFilter] = useState<Filter>("all");

  const counts = useMemo(
    () => ({
      all: notifications.length,
      critical: notifications.filter((n) => n.type === "critical").length,
      warning: notifications.filter((n) => n.type === "warning").length,
      info: notifications.filter((n) => n.type === "info").length,
    }),
    [notifications]
  );

  const list = notifications.filter((n) => filter === "all" || n.type === filter);

  return (
    <div className="flex h-full flex-col bg-bg">
      <StatusBar />
      <BackHeader
        title="Оповещения"
        subtitle={unreadCount > 0 ? `${unreadCount} непрочитанных` : "Все прочитаны"}
        right={
          <button
            onClick={markAllRead}
            className="flex items-center gap-1 rounded-full bg-surface-2 px-2.5 py-1.5 text-[11px] font-semibold text-tx-sec transition active:scale-90"
          >
            <CheckCheck className="h-3.5 w-3.5" />
            Все
          </button>
        }
      />

      {/* Фильтры */}
      <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1 no-scrollbar">
        <Chip active={filter === "all"} onClick={() => setFilter("all")} label="Все" count={counts.all} />
        <Chip active={filter === "critical"} onClick={() => setFilter("critical")} label="Критические" count={counts.critical} tone="red" />
        <Chip active={filter === "warning"} onClick={() => setFilter("warning")} label="Предупреждения" count={counts.warning} tone="amber" />
        <Chip active={filter === "info"} onClick={() => setFilter("info")} label="Информация" count={counts.info} tone="blue" />
      </div>

      <main className="flex-1 overflow-y-auto thin-scroll px-4 pb-28 pt-2">
        <div className="space-y-2.5">
          {list.map((n) => {
            const meta = TYPE_META[n.type];
            const Icon = meta.icon;
            return (
              <SwipeRow key={n.id} onSwipe={() => markRead(n.id)}>
                <div
                  className={cn(
                    "flex gap-3 rounded-2xl border p-3.5 transition",
                    n.read ? "border-line bg-surface" : "border-line bg-surface shadow-card"
                  )}
                >
                  <div className={cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-xl", meta.bg)}>
                    <Icon className={cn("h-5 w-5", meta.fg)} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-2">
                      <span className={cn("text-[10px] font-bold uppercase tracking-wide", meta.fg)}>
                        {meta.label}
                      </span>
                      {!n.read && <span className="mt-0.5 h-2 w-2 shrink-0 rounded-full bg-brand" />}
                    </div>
                    <p className={cn("mt-0.5 text-[13px] font-bold leading-snug", n.read ? "text-tx-sec" : "text-tx")}>
                      {n.title}
                    </p>
                    <p className="mt-1 text-[12px] leading-snug text-tx-sec">{n.body}</p>
                    <div className="mt-2 flex items-center gap-2 text-[10px] text-tx-muted">
                      <span className="font-medium">{n.source}</span>
                      <span>·</span>
                      <span>{n.time}</span>
                    </div>
                  </div>
                </div>
              </SwipeRow>
            );
          })}
        </div>

        {list.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <Bell className="h-10 w-10 text-tx-muted" strokeWidth={1.5} />
            <p className="mt-3 text-sm font-medium text-tx-sec">Нет уведомлений этого типа</p>
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
}

// ---- Чип фильтра ----
function Chip({
  active,
  onClick,
  label,
  count,
  tone = "green",
}: {
  active: boolean;
  onClick: () => void;
  label: string;
  count: number;
  tone?: "green" | "red" | "amber" | "blue";
}) {
  const tones = {
    green: "bg-brand text-white",
    red: "bg-red-500 text-white",
    amber: "bg-amber text-[#0F1B12]",
    blue: "bg-blue-500 text-white",
  };
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex shrink-0 items-center gap-1.5 rounded-full px-3 py-2 text-xs font-semibold transition active:scale-95",
        active ? tones[tone] : "bg-surface-2 text-tx-sec"
      )}
    >
      {label}
      <span className={cn("rounded-full px-1.5 text-[10px]", active ? "bg-white/25" : "bg-surface-3")}>
        {count}
      </span>
    </button>
  );
}

// ---- Строка со свайпом «прочитано» ----
function SwipeRow({ onSwipe, children }: { onSwipe: () => void; children: React.ReactNode }) {
  const [dx, setDx] = useState(0);
  const start = useRef<number | null>(null);

  return (
    <div className="relative overflow-hidden rounded-2xl">
      {/* Подложка действия */}
      <div className="absolute inset-0 flex items-center justify-end rounded-2xl bg-brand/15 pr-6">
        <span className="flex items-center gap-1.5 text-xs font-bold text-brand">
          <CheckCheck className="h-4 w-4" /> Прочитано
        </span>
      </div>
      {/* Перетаскиваемая карточка */}
      <div
        style={{ transform: `translateX(${dx}px)`, touchAction: "pan-y" }}
        onPointerDown={(e) => {
          start.current = e.clientX;
        }}
        onPointerMove={(e) => {
          if (start.current == null) return;
          setDx(Math.max(0, Math.min(120, e.clientX - start.current)));
        }}
        onPointerUp={() => {
          if (dx > 70) onSwipe();
          setDx(0);
          start.current = null;
        }}
        onPointerLeave={() => {
          setDx(0);
          start.current = null;
        }}
        className="relative"
      >
        {children}
      </div>
    </div>
  );
}
