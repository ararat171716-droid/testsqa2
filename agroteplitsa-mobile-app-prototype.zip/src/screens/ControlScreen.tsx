import { useState, type ReactNode } from "react";
import {
  Activity,
  Clock,
  Droplets,
  FlaskConical,
  Gauge,
  Lightbulb,
  Minus,
  Pause,
  Play,
  Plus,
  Power,
  Wind,
  Zap,
} from "lucide-react";
import { useApp } from "../AppContext";
import { GREENHOUSES } from "../data";
import {
  BackHeader,
  BottomNav,
  Card,
  Segmented,
  Slider,
  StatusBar,
  Tag,
  Toggle,
} from "../components/ui";
import { cn } from "../utils/cn";

// ============================================================
// Экран 3 · УПРАВЛЕНИЕ ИНЖЕНЕРНЫМИ СИСТЕМАМИ
// Освещение, фрамуги, капельный полив, питательный раствор,
// аварийный стоп. Состояние хранится в контексте.
// ============================================================

const PROGRAMS = [
  { n: 1, name: "Вегетация", desc: "N повышенный" },
  { n: 2, name: "Цветение", desc: "Баланс NPK" },
  { n: 3, name: "Плодоношение", desc: "K повышенный" },
];

export function ControlScreen() {
  const { control, setControl } = useApp();
  const [ventsMode, setVentsMode] = useState<"closed" | "half" | "open">("half");

  return (
    <div className="flex h-full flex-col bg-bg">
      <StatusBar />
      <BackHeader
        title="Управление"
        subtitle="Инженерные системы комплекса"
        right={
          <div className="flex items-center gap-1.5 rounded-full bg-brand/12 px-2.5 py-1">
            <span className="h-2 w-2 animate-pulse rounded-full bg-brand" />
            <span className="text-[11px] font-bold text-brand">онлайн</span>
          </div>
        }
      />

      <main className="flex-1 overflow-y-auto thin-scroll px-4 pb-4">
        {/* --- Освещение по теплицам --- */}
        <Section icon={Lightbulb} title="Досветка" subtitle="Интенсивность и расписание">
          <div className="space-y-2.5">
            {GREENHOUSES.map((g) => (
              <div key={g.id} className="flex items-center gap-3">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-tx">{g.name}</p>
                  <p className="truncate text-[11px] text-tx-sec">{g.culture}</p>
                </div>
                {control.lighting[g.id] && (
                  <Tag tone="amber">
                    <Clock className="h-3 w-3" /> до 20:00
                  </Tag>
                )}
                <Toggle
                  checked={control.lighting[g.id]}
                  onChange={(v) =>
                    setControl((p) => ({
                      ...p,
                      lighting: { ...p.lighting, [g.id]: v },
                    }))
                  }
                />
              </div>
            ))}
          </div>

          <div className="mt-4 border-t border-line pt-4">
            <div className="mb-2 flex items-center justify-between">
              <span className="text-sm font-semibold text-tx">Интенсивность досветки</span>
              <span className="text-sm font-extrabold text-amber">{control.intensity}%</span>
            </div>
            <Slider
              value={control.intensity}
              onChange={(v) => setControl((p) => ({ ...p, intensity: v }))}
              accent="var(--color-amber)"
            />
            <p className="mt-1 text-[11px] text-tx-muted">≈ {Math.round(control.intensity * 250)} лк добавочного света</p>
          </div>
        </Section>

        {/* --- Фрамуги --- */}
        <Section icon={Wind} title="Фрамуги" subtitle="Вентиляция и теплоотвод">
          <Segmented
            value={ventsMode}
            onChange={(v) => {
              setVentsMode(v);
              setControl((p) => ({ ...p, vents: v === "closed" ? 0 : v === "half" ? 45 : 90 }));
            }}
            options={[
              { value: "closed", label: "Закрыто" },
              { value: "half", label: "Частично" },
              { value: "open", label: "Открыто" },
            ]}
          />
          <div className="mt-4 flex items-center justify-between">
            <span className="text-sm font-semibold text-tx">Угол наклона</span>
            <span className="text-sm font-extrabold text-brand">{control.vents}°</span>
          </div>
          <div className="mt-1">
            <Slider value={control.vents} max={90} onChange={(v) => setControl((p) => ({ ...p, vents: v }))} />
          </div>
        </Section>

        {/* --- Капельный полив --- */}
        <Section icon={Droplets} title="Капельный полив" subtitle="Теплица №1 · Огурец «Кураж F1»">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setControl((p) => ({ ...p, irrigation: !p.irrigation }))}
              className={cn(
                "flex h-12 w-12 items-center justify-center rounded-2xl text-white shadow-soft transition active:scale-90",
                control.irrigation ? "bg-brand" : "bg-brand/40"
              )}
            >
              {control.irrigation ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6 translate-x-0.5" />}
            </button>
            <div className="flex-1">
              <p className="text-sm font-bold text-tx">
                {control.irrigation ? "Полив выполняется" : "Полив остановлен"}
              </p>
              <p className="text-[11px] text-tx-sec">
                {control.irrigation ? `Осталось ~${control.irrigationMin} мин` : "Готов к запуску"}
              </p>
            </div>
            <Stepper
              value={control.irrigationMin}
              min={5}
              max={60}
              step={1}
              unit="мин"
              onChange={(v) => setControl((p) => ({ ...p, irrigationMin: v }))}
            />
          </div>
        </Section>

        {/* --- Питательный раствор --- */}
        <Section icon={FlaskConical} title="Питательный раствор" subtitle="EC / pH и программа">
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-2xl bg-surface-2 p-3">
              <div className="flex items-center gap-1.5 text-tx-sec">
                <Activity className="h-3.5 w-3.5" />
                <span className="text-[11px] font-semibold">EC</span>
              </div>
              <Stepper
                value={control.ec}
                min={1.0}
                max={4.0}
                step={0.1}
                unit="мСм"
                decimals
                onChange={(v) => setControl((p) => ({ ...p, ec: v }))}
              />
            </div>
            <div className="rounded-2xl bg-surface-2 p-3">
              <div className="flex items-center gap-1.5 text-tx-sec">
                <Gauge className="h-3.5 w-3.5" />
                <span className="text-[11px] font-semibold">pH</span>
              </div>
              <Stepper
                value={control.ph}
                min={4.5}
                max={7.5}
                step={0.1}
                unit=""
                decimals
                onChange={(v) => setControl((p) => ({ ...p, ph: v }))}
              />
            </div>
          </div>

          <p className="mb-2 mt-4 text-xs font-bold uppercase tracking-wide text-tx-muted">
            Программа внесения
          </p>
          <div className="grid grid-cols-3 gap-2">
            {PROGRAMS.map((pr) => {
              const active = control.nutrientProgram === pr.n;
              return (
                <button
                  key={pr.n}
                  onClick={() => setControl((p) => ({ ...p, nutrientProgram: pr.n as 1 | 2 | 3 }))}
                  className={cn(
                    "rounded-2xl border p-2.5 text-center transition active:scale-95",
                    active ? "border-brand bg-brand/8" : "border-line bg-surface"
                  )}
                >
                  <p className={cn("text-sm font-extrabold", active ? "text-brand" : "text-tx")}>№{pr.n}</p>
                  <p className="text-[10px] font-semibold text-tx-sec">{pr.name}</p>
                  <p className="text-[9px] text-tx-muted">{pr.desc}</p>
                </button>
              );
            })}
          </div>
        </Section>

        {/* --- Аварийный стоп --- */}
        <div className="mt-2">
          <button
            onClick={() => setControl((p) => ({ ...p, emergency: !p.emergency }))}
            className={cn(
              "flex w-full items-center justify-center gap-2.5 rounded-2xl py-4 text-[15px] font-bold text-white shadow-soft transition active:scale-[0.98]",
              control.emergency ? "bg-brand" : "bg-red-600"
            )}
          >
            <Power className="h-6 w-6" />
            {control.emergency ? "Снять аварийную блокировку" : "Аварийный стоп"}
          </button>
          {control.emergency && (
            <div className="mt-2 flex items-center gap-2 rounded-2xl border border-red-500/40 bg-red-500/8 p-3">
              <Zap className="h-5 w-5 text-red-500" />
              <p className="text-xs font-semibold text-red-500">
                Все исполнительные механизмы остановлены. Уведомление отправлено техническому специалисту.
              </p>
            </div>
          )}
        </div>
      </main>

      <BottomNav />
    </div>
  );
}

// ---- Карточка секции управления ----
function Section({
  icon: Icon,
  title,
  subtitle,
  children,
}: {
  icon: typeof Lightbulb;
  title: string;
  subtitle: string;
  children: ReactNode;
}) {
  return (
    <Card className="mb-3 p-4">
      <div className="mb-3 flex items-center gap-2.5">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand/12">
          <Icon className="h-5 w-5 text-brand" />
        </div>
        <div>
          <h3 className="text-[15px] font-bold leading-tight text-tx">{title}</h3>
          <p className="text-[11px] text-tx-sec">{subtitle}</p>
        </div>
      </div>
      {children}
    </Card>
  );
}

// ---- Степпер +/− для числовых значений ----
function Stepper({
  value,
  min,
  max,
  step,
  unit,
  decimals,
  onChange,
}: {
  value: number;
  min: number;
  max: number;
  step: number;
  unit: string;
  decimals?: boolean;
  onChange: (v: number) => void;
}) {
  const fmt = decimals ? value.toFixed(1) : Math.round(value);
  return (
    <div className="flex items-center gap-1.5">
      <button
        onClick={() => onChange(Math.max(min, +(value - step).toFixed(2)))}
        className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-tx transition active:scale-90"
      >
        <Minus className="h-4 w-4" />
      </button>
      <div className="min-w-[44px] text-center">
        <span className="text-sm font-extrabold text-tx">{fmt}</span>
        {unit && <span className="ml-0.5 text-[10px] text-tx-sec">{unit}</span>}
      </div>
      <button
        onClick={() => onChange(Math.min(max, +(value + step).toFixed(2)))}
        className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-tx transition active:scale-90"
      >
        <Plus className="h-4 w-4" />
      </button>
    </div>
  );
}
