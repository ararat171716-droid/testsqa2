import { useState } from "react";
import {
  AlertTriangle,
  BarChart3,
  Bell,
  ChevronRight,
  CloudSun,
  Droplets,
  Eye,
  Settings,
  ShieldCheck,
  Sprout,
  Sun,
  Thermometer,
  TrendingUp,
  Star,
  X,
} from "lucide-react";
import { useApp } from "../AppContext";
import { GREENHOUSES, PHASE_LABELS } from "../data";
import { StatusBar, Card, BottomNav, StatusDot, Tag } from "../components/ui";
import { cn } from "../utils/cn";
import type { Greenhouse } from "../types";

// ============================================================
// Экран 2 · ГЛАВНЫЙ ДАШБОРД
// Стеклянная шапка с приветствием и статусом, плитки 2×2 ключевых
// метрик микроклимата, горизонтальный список теплиц.
// ============================================================

/** Приветствие по имени-отчеству (без фамилии) */
function greetingName(full: string) {
  return full.split(" ").slice(0, 2).join(" ");
}

export function DashboardScreen() {
  const { userName, navigate, unreadCount } = useApp();

  // Инициалы из введённого имени (первые буквы имени и фамилии)
  const initials = userName
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase())
    .join("");

  // Состояние: скрыт ли баннер предупреждения пользователем
  const [dismissed, setDismissed] = useState(false);

  // Анализ статуса комплекса
  const warnings = GREENHOUSES.filter((g) => g.status !== "ok");
  const hasWarnings = warnings.length > 0;

  return (
    <div className="flex h-full flex-col bg-bg">
      {/* ===== Стеклянная шапка с агрозелёным градиентом ===== */}
      <div className="relative shrink-0 bg-gradient-to-br from-brand via-brand to-brand-dark pb-14">
        <StatusBar tone="light" />
        <div className="absolute -right-10 -top-6 h-40 w-40 rounded-full bg-amber/20 blur-3xl" />

        <div className="relative px-5 pt-1">
          {/* Аватар + уведомления */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-white/20 text-sm font-bold text-white ring-2 ring-white/30">
                {initials || "АТ"}
              </div>
              <div>
                <p className="text-xs font-medium text-white/70">Доброе утро,</p>
                <p className="text-[15px] font-bold text-white">
                  {greetingName(userName)}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => navigate("settings")}
                className="flex h-11 w-11 items-center justify-center rounded-full bg-white/15 transition active:scale-90"
              >
                <Settings className="h-5 w-5 text-white" />
              </button>
              <button
                onClick={() => navigate("notifications")}
                className="relative flex h-11 w-11 items-center justify-center rounded-full bg-white/15 transition active:scale-90"
              >
                <Bell className="h-5 w-5 text-white" />
                {unreadCount > 0 && (
                  <span className="absolute right-2 top-2 h-2.5 w-2.5 rounded-full bg-amber ring-2 ring-brand" />
                )}
              </button>
            </div>
          </div>

          {/* Статус комплекса (баннер предупреждения можно закрыть) */}
          <div className="mt-5">
            {hasWarnings && !dismissed ? (
              <StatusBadge
                tone="warning"
                title={`${warnings.length} теплица требует внимания`}
                subtitle="Отклонения микроклимата от нормы"
                onDismiss={() => setDismissed(true)}
              />
            ) : (
              <StatusBadge
                tone="ok"
                title={dismissed && hasWarnings ? "Мониторинг активен" : "Все системы в норме"}
                subtitle={dismissed && hasWarnings ? "Уведомление скрыто · нажмите, чтобы вернуть" : "Комплекс работает штатно"}
                onRestore={dismissed && hasWarnings ? () => setDismissed(false) : undefined}
              />
            )}
          </div>
        </div>
      </div>

      {/* ===== Прокручиваемый контент (z-10 — поверх зелёной шапки) ===== */}
      <main className="relative z-10 -mt-10 flex-1 overflow-y-auto thin-scroll px-4 pb-28">
        {/* Плитки метрик 2×2 */}
        <div className="grid grid-cols-2 gap-3">
          <MetricTile
            icon={Thermometer}
            tint="bg-brand/12 text-brand"
            label="Температура"
            value="24,5"
            unit="°C"
            target="цель 25 °C"
            onClick={() => navigate("greenhouse", { id: "gh1" })}
          />
          <MetricTile
            icon={Droplets}
            tint="bg-blue-500/12 text-blue-500"
            label="Влажность воздуха"
            value="68"
            unit="%"
            sub="норма 60–75%"
          />
          <MetricTile
            icon={Sun}
            tint="bg-amber/15 text-amber"
            label="Освещённость"
            value="18 500"
            unit="лк"
            sub="досветка 75%"
          />
          <MetricTile
            icon={Sprout}
            tint="bg-brand/12 text-brand"
            label="Влажность почвы"
            value="42"
            unit="%"
            target="цель 45%"
          />
        </div>

        {/* Погода снаружи */}
        <Card className="mt-3 flex items-center gap-3 p-3.5">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-amber/15">
            <CloudSun className="h-6 w-6 text-amber" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-semibold text-tx">На улице +19° · ясно</p>
            <p className="text-xs text-tx-sec">Саратовская обл. · ветер 3 м/с</p>
          </div>
          <Tag tone="green">
            <TrendingUp className="h-3 w-3" /> Режим «день»
          </Tag>
        </Card>

        {/* Быстрый доступ */}
        <div className="mt-3 grid grid-cols-2 gap-3">
          <QuickAccess icon={BarChart3} label="Аналитика" onClick={() => navigate("analytics")} />
          <QuickAccess icon={Settings} label="Настройки" onClick={() => navigate("settings")} />
        </div>

        {/* Список теплиц */}
        <div className="mb-2 mt-6 flex items-center justify-between">
          <h2 className="text-[17px] font-bold text-tx">Теплицы</h2>
          <span className="text-xs font-semibold text-tx-muted">{GREENHOUSES.length} объекта</span>
        </div>

        <div className="-mx-4 flex gap-3 overflow-x-auto px-4 pb-2 no-scrollbar">
          {GREENHOUSES.map((g) => (
            <GreenhouseCard key={g.id} gh={g} onClick={() => navigate("greenhouse", { id: g.id })} />
          ))}
        </div>

        {/* Демонстрационный экран для защиты диплома */}
        <button
          onClick={() => navigate("summary")}
          className="mt-5 flex w-full items-center gap-3 rounded-2xl border border-amber/40 bg-amber/8 p-3.5 transition active:scale-[0.99]"
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber/20">
            <Star className="h-5 w-5 text-amber" />
          </div>
          <div className="flex-1 text-left">
            <p className="text-[13px] font-bold text-tx">Сводный экран для защиты</p>
            <p className="text-[11px] text-tx-sec">Презентация приложения комиссии за 10 секунд</p>
          </div>
          <ChevronRight className="h-5 w-5 text-amber" />
        </button>
      </main>

      <BottomNav />
    </div>
  );
}

// ---- Баннер статуса (предупреждение можно закрыть) ----
function StatusBadge({
  tone,
  title,
  subtitle,
  onDismiss,
  onRestore,
}: {
  tone: "ok" | "warning";
  title: string;
  subtitle: string;
  onDismiss?: () => void;
  onRestore?: () => void;
}) {
  // Скрытый баннер: компактная кнопка-восстановление
  if (onRestore) {
    return (
      <button
        onClick={onRestore}
        className="glass flex w-full items-center gap-3 rounded-2xl border border-white/20 p-3.5 text-left transition active:scale-[0.99]"
      >
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/15">
          <ShieldCheck className="h-5 w-5 text-amber-light" />
        </div>
        <div className="flex-1">
          <p className="text-[15px] font-bold text-white">{title}</p>
          <p className="text-xs text-white/75">{subtitle}</p>
        </div>
        <Eye className="h-5 w-5 text-white/60" />
      </button>
    );
  }

  return (
    <div className="glass flex items-center gap-3 rounded-2xl border border-white/30 p-3.5">
      <div
        className={cn(
          "flex h-10 w-10 items-center justify-center rounded-xl",
          tone === "ok" ? "bg-amber/20" : "bg-amber/25"
        )}
      >
        {tone === "ok" ? (
          <CloudSun className="h-5 w-5 text-amber-light" />
        ) : (
          <AlertTriangle className="h-5 w-5 text-amber" />
        )}
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-[15px] font-bold text-white">{title}</p>
        <p className="text-xs text-white/75">{subtitle}</p>
      </div>
      {onDismiss ? (
        <button
          onClick={onDismiss}
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white/15 text-white transition hover:bg-white/25 active:scale-90"
          aria-label="Скрыть предупреждение"
        >
          <X className="h-4 w-4" />
        </button>
      ) : (
        <StatusDot status={tone === "ok" ? "ok" : "warning"} />
      )}
    </div>
  );
}

// ---- Плитка метрики ----
function MetricTile({
  icon: Icon,
  tint,
  label,
  value,
  unit,
  target,
  sub,
  onClick,
}: {
  icon: typeof Thermometer;
  tint: string;
  label: string;
  value: string;
  unit: string;
  target?: string;
  sub?: string;
  onClick?: () => void;
}) {
  return (
    <Card onClick={onClick} className="p-3.5">
      <div className={cn("flex h-9 w-9 items-center justify-center rounded-xl", tint)}>
        <Icon className="h-5 w-5" strokeWidth={2.2} />
      </div>
      <p className="mt-3 text-xs font-medium text-tx-sec">{label}</p>
      <div className="mt-0.5 flex items-baseline gap-1">
        <span className="text-[26px] font-extrabold leading-none tracking-tight text-tx">
          {value}
        </span>
        <span className="text-sm font-semibold text-tx-sec">{unit}</span>
      </div>
      {target ? (
        <p className="mt-1 text-[11px] font-semibold text-brand">{target}</p>
      ) : (
        <p className="mt-1 text-[11px] text-tx-muted">{sub}</p>
      )}
    </Card>
  );
}

// ---- Карточка теплицы (горизонтальный список) ----
function GreenhouseCard({ gh, onClick }: { gh: Greenhouse; onClick: () => void }) {
  const tint =
    gh.status === "ok" ? "ok" : gh.status === "warning" ? "warning" : "critical";
  return (
    <Card onClick={onClick} className="w-[170px] shrink-0 p-3.5">
      <div className="flex items-center justify-between">
        <span className="text-sm font-bold text-tx">{gh.name}</span>
        <StatusDot status={tint} />
      </div>
      <p className="mt-0.5 truncate text-xs text-tx-sec">{gh.culture}</p>
      <Tag tone="green" className="mt-2">
        {PHASE_LABELS[gh.phase]}
      </Tag>
      <div className="mt-3 flex gap-3 border-t border-line pt-2.5">
        <div className="flex items-center gap-1">
          <Thermometer className="h-3.5 w-3.5 text-tx-muted" />
          <span className="text-xs font-bold text-tx">{gh.temp}°</span>
        </div>
        <div className="flex items-center gap-1">
          <Droplets className="h-3.5 w-3.5 text-tx-muted" />
          <span className="text-xs font-bold text-tx">{gh.humidity}%</span>
        </div>
      </div>
    </Card>
  );
}

// ---- Карточка быстрого доступа ----
function QuickAccess({
  icon: Icon,
  label,
  onClick,
}: {
  icon: typeof Thermometer;
  label: string;
  onClick: () => void;
}) {
  return (
    <Card onClick={onClick} className="flex items-center gap-2.5 p-3">
      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand/12">
        <Icon className="h-5 w-5 text-brand" />
      </div>
      <span className="text-[13px] font-bold text-tx">{label}</span>
      <ChevronRight className="ml-auto h-4 w-4 text-tx-muted" />
    </Card>
  );
}
