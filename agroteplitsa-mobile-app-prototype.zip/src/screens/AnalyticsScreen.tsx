import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  Clock,
  Download,
  Droplets,
  FileText,
  Sprout,
  TrendingUp,
  Zap,
} from "lucide-react";
import { ECONOMIC_EFFECT, ECONOMICS, KPIS } from "../data";
import { BackHeader, BottomNav, Card, StatusBar, Tag } from "../components/ui";
import { cn } from "../utils/cn";

// ============================================================
// Экран 8 · АНАЛИТИКА И ОТЧЁТЫ (для руководителя)
// KPI, столбчатый график экономического эффекта,
// индикатор срока окупаемости, экспорт отчёта.
// ============================================================

export function AnalyticsScreen() {
  return (
    <div className="flex h-full flex-col bg-bg">
      <StatusBar />
      <BackHeader title="Аналитика" subtitle="KPI и экономический эффект" />

      <main className="flex-1 overflow-y-auto thin-scroll px-4 pb-28">
        {/* KPI-карточки */}
        <div className="grid grid-cols-2 gap-3">
          <KpiCard
            icon={Clock}
            tint="bg-brand/12 text-brand"
            value="72"
            unit="мин/день"
            label="Экономия времени"
            range={`диапазон ${KPIS.timeSaveRange} мин`}
            sub={`${KPIS.timeSaveHours} ч в год`}
          />
          <KpiCard
            icon={Droplets}
            tint="bg-blue-500/12 text-blue-500"
            value={`${KPIS.waterSave}`}
            unit="%"
            label="Экономия воды"
            range="капельный полив + IoT"
            sub="~44 м³/мес"
          />
          <KpiCard
            icon={Zap}
            tint="bg-amber/15 text-amber"
            value={`${KPIS.energySave}`}
            unit="%"
            label="Экономия э/э"
            range="умная досветка"
            sub="~500 кВт·ч/мес"
          />
          <KpiCard
            icon={Sprout}
            tint="bg-brand/12 text-brand"
            value={`${KPIS.yield}`}
            unit="кг/м²"
            label="Урожайность"
            range="+8% к плану"
            sub="огурец Кураж F1"
          />
        </div>

        {/* График экономического эффекта */}
        <Card className="mt-3 p-4">
          <div className="mb-1 flex items-center justify-between">
            <h3 className="text-[15px] font-bold text-tx">Экономический эффект</h3>
            <Tag tone="green">тыс. руб/год</Tag>
          </div>
          <p className="mb-3 text-[11px] text-tx-sec">
            Совокупный годовой эффект от внедрения системы
          </p>
          <div className="h-[180px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={ECONOMIC_EFFECT} margin={{ top: 5, right: 0, left: -22, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-line)" vertical={false} />
                <XAxis
                  dataKey="short"
                  tick={{ fontSize: 11, fill: "var(--color-tx-sec)" }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: "var(--color-tx-muted)" }}
                  axisLine={false}
                  tickLine={false}
                  width={34}
                />
                <Tooltip content={<BarTip />} cursor={{ fill: "var(--color-surface-2)" }} />
                <Bar dataKey="value" radius={[8, 8, 0, 0]} maxBarSize={64}>
                  {ECONOMIC_EFFECT.map((e) => (
                    <Cell key={e.short} fill={e.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-2 flex items-center justify-center gap-1.5 rounded-xl bg-brand/8 py-2">
            <TrendingUp className="h-4 w-4 text-brand" />
            <span className="text-sm font-bold text-brand">
              Итого {ECONOMICS.effect} тыс. руб/год
            </span>
          </div>
        </Card>

        {/* Срок окупаемости */}
        <Card className="mt-3 p-4">
          <h3 className="text-[15px] font-bold text-tx">Срок окупаемости</h3>
          <div className="mt-3 flex items-end gap-2">
            <span className="text-4xl font-extrabold text-tx">{ECONOMICS.payback}</span>
            <span className="mb-1 text-sm font-semibold text-tx-sec">года</span>
          </div>

          {/* Шкала окупаемости */}
          <div className="relative mt-4 h-2.5 rounded-full bg-gradient-to-r from-brand via-amber to-red-400">
            <div className="absolute left-1/2 top-1/2 h-5 w-5 -translate-x-1/2 -translate-y-1/2 rounded-full border-[3px] border-surface bg-amber shadow" />
          </div>
          <div className="mt-1.5 flex justify-between text-[10px] font-medium text-tx-muted">
            <span>быстро · 1,5 г</span>
            <span>3,1 г</span>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-2">
            <div className="rounded-xl bg-surface-2 p-2.5">
              <p className="text-[10px] text-tx-sec">Стоимость внедрения</p>
              <p className="text-sm font-extrabold text-tx">{ECONOMICS.investment} тыс ₽</p>
            </div>
            <div className="rounded-xl bg-surface-2 p-2.5">
              <p className="text-[10px] text-tx-sec">Годовой эффект</p>
              <p className="text-sm font-extrabold text-brand">{ECONOMICS.effect} тыс ₽</p>
            </div>
          </div>
        </Card>

        {/* Экспорт отчёта */}
        <p className="mb-2 mt-5 text-[15px] font-bold text-tx">Экспорт отчёта</p>
        <div className="grid grid-cols-2 gap-3">
          <ExportBtn icon={FileText} label="PDF" desc="Сводный отчёт" />
          <ExportBtn icon={Download} label="Excel" desc="Таблицы данных" />
        </div>
      </main>

      <BottomNav />
    </div>
  );
}

// ---- KPI-карточка ----
function KpiCard({
  icon: Icon,
  tint,
  value,
  unit,
  label,
  range,
  sub,
}: {
  icon: typeof Clock;
  tint: string;
  value: string;
  unit: string;
  label: string;
  range: string;
  sub: string;
}) {
  return (
    <Card className="p-3.5">
      <div className={cn("flex h-9 w-9 items-center justify-center rounded-xl", tint)}>
        <Icon className="h-5 w-5" strokeWidth={2.2} />
      </div>
      <p className="mt-2.5 text-[11px] font-medium text-tx-sec">{label}</p>
      <div className="flex items-baseline gap-1">
        <span className="text-[26px] font-extrabold leading-none text-tx">{value}</span>
        <span className="text-xs font-semibold text-tx-sec">{unit}</span>
      </div>
      <p className="mt-1 text-[10px] font-medium text-brand">{range}</p>
      <p className="text-[10px] text-tx-muted">{sub}</p>
    </Card>
  );
}

// ---- Тултип столбчатого графика ----
function BarTip({ active, payload }: any) {
  if (!active || !payload?.length) return null;
  const p = payload[0].payload;
  return (
    <div className="rounded-xl border border-line bg-surface px-3 py-2 shadow-soft">
      <p className="text-[11px] font-semibold text-tx">{p.name}</p>
      <p className="text-sm font-extrabold text-brand">{p.value} тыс. ₽</p>
    </div>
  );
}

// ---- Кнопка экспорта ----
function ExportBtn({
  icon: Icon,
  label,
  desc,
}: {
  icon: typeof FileText;
  label: string;
  desc: string;
}) {
  return (
    <button className="flex flex-col items-start gap-2 rounded-2xl border border-line bg-surface p-3.5 text-left transition hover:border-brand/40 active:scale-[0.97]">
      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand/12">
        <Icon className="h-5 w-5 text-brand" />
      </div>
      <div>
        <p className="text-sm font-bold text-tx">{label}</p>
        <p className="text-[11px] text-tx-sec">{desc}</p>
      </div>
    </button>
  );
}
