import { useState } from "react";
import {
  ChevronRight,
  Cpu,
  Database,
  Globe,
  Info,
  KeyRound,
  LogOut,
  Minus,
  Moon,
  Plus,
  Satellite,
  ShieldCheck,
  Star,
  Sun,
  Thermometer,
  User,
  Wifi,
} from "lucide-react";
import { useApp } from "../AppContext";
import { AUTHOR, THESIS, DEVICES, ROLES } from "../data";
import { BackHeader, BottomNav, Card, StatusBar, StatusDot, Tag, Toggle } from "../components/ui";
import { cn } from "../utils/cn";

// ============================================================
// Экран 9 · НАСТРОЙКИ
// Профиль, пороги микроклимата, IoT-устройства, интеграции,
// тёмная/светлая тема, язык.
// ============================================================

export function SettingsScreen() {
  const { userName, role, theme, toggleTheme, lang, setLang, reset, navigate } = useApp();
  const roleTitle = ROLES.find((r) => r.id === role)?.title ?? "Пользователь";
  // Инициалы из введённого имени
  const initials = userName
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase())
    .join("");

  const [thresholds, setThresholds] = useState({
    tMin: 22,
    tMax: 28,
    hMin: 60,
    hMax: 80,
  });
  const [integrations, setIntegrations] = useState({ oneC: true, glonass: true, weather: false });

  return (
    <div className="flex h-full flex-col bg-bg">
      <StatusBar />
      <BackHeader title="Настройки" subtitle="Профиль и параметры системы" />

      <main className="flex-1 overflow-y-auto thin-scroll px-4 pb-28">
        {/* --- Профиль --- */}
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-light to-brand-dark text-lg font-bold text-white">
              {initials || "АТ"}
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[15px] font-bold text-tx">{userName}</p>
              <Tag tone="green" className="mt-1">
                <ShieldCheck className="h-3 w-3" /> {roleTitle}
              </Tag>
            </div>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <ActionRow icon={User} label="Профиль" onClick={() => {}} />
            <ActionRow icon={KeyRound} label="Сменить пароль" onClick={() => {}} />
          </div>
        </Card>

        {/* --- Пороги микроклимата --- */}
        <SectionTitle icon={Thermometer} title="Пороги микроклимата" hint="Огурец «Кураж F1»" />
        <Card className="space-y-3 p-4">
          <ThresholdRow label="Температура, мин" value={thresholds.tMin} unit="°C" onChange={(v) => setThresholds((s) => ({ ...s, tMin: v }))} min={15} max={25} />
          <ThresholdRow label="Температура, макс" value={thresholds.tMax} unit="°C" onChange={(v) => setThresholds((s) => ({ ...s, tMax: v }))} min={25} max={35} />
          <ThresholdRow label="Влажность, мин" value={thresholds.hMin} unit="%" onChange={(v) => setThresholds((s) => ({ ...s, hMin: v }))} min={40} max={65} />
          <ThresholdRow label="Влажность, макс" value={thresholds.hMax} unit="%" onChange={(v) => setThresholds((s) => ({ ...s, hMax: v }))} min={70} max={95} />
        </Card>

        {/* --- IoT-устройства --- */}
        <SectionTitle icon={Cpu} title="IoT-устройства" hint={`${DEVICES.length} подкл.`} />
        <Card className="divide-y divide-line overflow-hidden">
          {DEVICES.map((d) => {
            const ok = d.status === "online";
            return (
              <div key={d.id} className="flex items-center gap-3 p-3.5">
                <div
                  className={cn(
                    "flex h-9 w-9 items-center justify-center rounded-xl",
                    ok ? "bg-brand/12" : d.status === "warning" ? "bg-amber/15" : "bg-red-500/12"
                  )}
                >
                  <Wifi className={cn("h-4 w-4", ok ? "text-brand" : d.status === "warning" ? "text-amber" : "text-red-500")} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px] font-semibold text-tx">{d.name}</p>
                  <p className="truncate text-[11px] text-tx-sec">{d.location} · {d.type}</p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <StatusDot status={ok ? "ok" : d.status === "warning" ? "warning" : "critical"} />
                  {d.battery != null && (
                    <span className="text-[10px] font-medium text-tx-muted">{d.battery}%</span>
                  )}
                </div>
              </div>
            );
          })}
        </Card>

        {/* --- Интеграции --- */}
        <SectionTitle icon={Database} title="Интеграции" />
        <Card className="divide-y divide-line overflow-hidden">
          <ToggleRow icon={Database} label="1С:Предприятие" desc="Бухучёт и склад" checked={integrations.oneC} onChange={(v) => setIntegrations((s) => ({ ...s, oneC: v }))} />
          <ToggleRow icon={Satellite} label="ЭРА-ГЛОНАСС" desc="Экстренное оповещение" checked={integrations.glonass} onChange={(v) => setIntegrations((s) => ({ ...s, glonass: v }))} />
          <ToggleRow icon={Globe} label="Метеосервис" desc="Прогноз погоды" checked={integrations.weather} onChange={(v) => setIntegrations((s) => ({ ...s, weather: v }))} />
        </Card>

        {/* --- Внешний вид --- */}
        <SectionTitle icon={Sun} title="Внешний вид" />
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              {theme === "dark" ? <Moon className="h-5 w-5 text-tx-sec" /> : <Sun className="h-5 w-5 text-amber" />}
              <div>
                <p className="text-sm font-semibold text-tx">Тёмная тема</p>
                <p className="text-[11px] text-tx-sec">Адаптивное оформление</p>
              </div>
            </div>
            <Toggle checked={theme === "dark"} onChange={toggleTheme} />
          </div>
          <div className="mt-3 flex items-center justify-between border-t border-line pt-3">
            <div className="flex items-center gap-2.5">
              <Globe className="h-5 w-5 text-tx-sec" />
              <p className="text-sm font-semibold text-tx">Язык интерфейса</p>
            </div>
            <div className="flex rounded-full bg-surface-2 p-1">
              {(["RU", "EN"] as const).map((l) => (
                <button
                  key={l}
                  onClick={() => setLang(l)}
                  className={cn(
                    "rounded-full px-3 py-1 text-xs font-bold transition",
                    lang === l ? "bg-surface text-tx shadow-sm" : "text-tx-sec"
                  )}
                >
                  {l}
                </button>
              ))}
            </div>
          </div>
        </Card>

        {/* --- Доп. разделы --- */}
        <SectionTitle icon={Info} title="Дополнительно" />
        <Card className="divide-y divide-line overflow-hidden">
          <NavRow icon={Info} label="О приложении" desc="Научное обоснование" onClick={() => navigate("about")} />
          <NavRow icon={Star} label="Сводный экран защиты" desc="Демонстрация комиссии" onClick={() => navigate("summary")} />
        </Card>

        {/* --- Выход --- */}
        <button
          onClick={() => reset("auth")}
          className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl border border-red-500/30 bg-red-500/8 py-3.5 text-sm font-bold text-red-500 transition active:scale-[0.98]"
        >
          <LogOut className="h-5 w-5" />
          Выйти из аккаунта
        </button>

        <div className="mt-5 rounded-2xl border border-line bg-surface-2 p-3.5">
          <p className="text-center text-[13px] font-bold text-tx">{AUTHOR.name}</p>
          <p className="mt-0.5 text-center text-[11px] text-tx-sec">
            {AUTHOR.course}, {AUTHOR.university}
          </p>
          <p className="mt-2 text-center text-[11px] leading-snug text-tx-muted">{THESIS.short}</p>
        </div>

        <p className="mt-4 text-center text-[11px] text-tx-muted">
          АгроТеплица.Контроль · версия 1.0.0
        </p>
      </main>

      <BottomNav />
    </div>
  );
}

// ---- Заголовок секции ----
function SectionTitle({
  icon: Icon,
  title,
  hint,
}: {
  icon: typeof Cpu;
  title: string;
  hint?: string;
}) {
  return (
    <div className="mb-2 mt-5 flex items-center gap-2 px-1">
      <Icon className="h-4 w-4 text-tx-sec" />
      <h2 className="text-[13px] font-bold uppercase tracking-wide text-tx-sec">{title}</h2>
      {hint && <span className="ml-auto text-[11px] text-tx-muted">{hint}</span>}
    </div>
  );
}

// ---- Строка с переключателем ----
function ToggleRow({
  icon: Icon,
  label,
  desc,
  checked,
  onChange,
}: {
  icon: typeof Database;
  label: string;
  desc: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center gap-3 p-3.5">
      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-surface-2">
        <Icon className="h-4 w-4 text-tx-sec" />
      </div>
      <div className="flex-1">
        <p className="text-sm font-semibold text-tx">{label}</p>
        <p className="text-[11px] text-tx-sec">{desc}</p>
      </div>
      <Toggle checked={checked} onChange={onChange} />
    </div>
  );
}

// ---- Строка навигации ----
function NavRow({
  icon: Icon,
  label,
  desc,
  onClick,
}: {
  icon: typeof Info;
  label: string;
  desc: string;
  onClick: () => void;
}) {
  return (
    <button onClick={onClick} className="flex w-full items-center gap-3 p-3.5 text-left transition active:bg-surface-2">
      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-surface-2">
        <Icon className="h-4 w-4 text-brand" />
      </div>
      <div className="flex-1">
        <p className="text-sm font-semibold text-tx">{label}</p>
        <p className="text-[11px] text-tx-sec">{desc}</p>
      </div>
      <ChevronRight className="h-5 w-5 text-tx-muted" />
    </button>
  );
}

// ---- Компактное действие ----
function ActionRow({ icon: Icon, label, onClick }: { icon: typeof User; label: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center justify-center gap-2 rounded-xl bg-surface-2 py-2.5 text-xs font-semibold text-tx transition active:scale-95"
    >
      <Icon className="h-4 w-4 text-brand" />
      {label}
    </button>
  );
}

// ---- Пороговое значение со степпером ----
function ThresholdRow({
  label,
  value,
  unit,
  min,
  max,
  onChange,
}: {
  label: string;
  value: number;
  unit: string;
  min: number;
  max: number;
  onChange: (v: number) => void;
}) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-[13px] text-tx-sec">{label}</span>
      <div className="flex items-center gap-2">
        <button
          onClick={() => onChange(Math.max(min, value - 1))}
          className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-tx transition active:scale-90"
        >
          <Minus className="h-3.5 w-3.5" />
        </button>
        <span className="w-14 text-center text-sm font-extrabold text-tx">
          {value} {unit}
        </span>
        <button
          onClick={() => onChange(Math.min(max, value + 1))}
          className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-2 text-tx transition active:scale-90"
        >
          <Plus className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
}
