import { useState } from "react";
import {
  CartesianGrid,
  ComposedChart,
  Line,
  Area,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Droplets, Sprout, Sun, Thermometer } from "lucide-react";
import { GREENHOUSES, PHASE_LABELS, TEMP_24H, TEMP_7D, TEMP_30D } from "../data";
import { BackHeader, Card, Segmented, StatusBar, StatusDot, Tag } from "../components/ui";
import { cn } from "../utils/cn";
import type { ChartPoint, Phase } from "../types";

// ============================================================
// Экран 4 · ДЕТАЛИЗАЦИЯ ТЕПЛИЦЫ
// Линейные графики температуры/влажности за 24ч, 7д, 30д
// и индикатор фаз вегетации культуры.
// ============================================================

const PHASE_ORDER: Phase[] = ["seeding", "vegetation", "flowering", "fruiting"];
const PHASE_ICONS = ["🌱", "🌿", "🌼", "🥒"]; // условные эмодзи фаз

type Period = "24h" | "7d" | "30d";

export function GreenhouseDetailScreen({ params }: { params?: Record<string, string> }) {
  const gh = GREENHOUSES.find((g) => g.id === params?.id) ?? GREENHOUSES[0];
  const [period, setPeriod] = useState<Period>("24h");

  const data: ChartPoint[] =
    period === "24h" ? TEMP_24H : period === "7d" ? TEMP_7D : TEMP_30D;
  const showTarget = period === "24h";

  const currentPhaseIdx = PHASE_ORDER.indexOf(gh.phase);
  const periodLabel = period === "24h" ? "за 24 часа" : period === "7d" ? "за 7 дней" : "за 30 дней";

  return (
    <div className="flex h-full flex-col bg-bg">
      <StatusBar />
      <BackHeader
        title={gh.name}
        subtitle={gh.culture}
        right={
          <div className="flex items-center gap-1.5">
            <StatusDot status={gh.status} />
          </div>
        }
      />

      <main className="flex-1 overflow-y-auto thin-scroll px-4 pb-28">
        {/* Текущие показатели */}
        <div className="grid grid-cols-4 gap-2">
          <MiniStat icon={Thermometer} tint="text-brand" value={`${gh.temp}`} unit="°C" />
          <MiniStat icon={Droplets} tint="text-blue-500" value={`${gh.humidity}`} unit="%" />
          <MiniStat icon={Sun} tint="text-amber" value={`${(gh.light / 1000).toFixed(1)}`} unit="клк" />
          <MiniStat icon={Sprout} tint="text-brand" value={`${gh.soil}`} unit="%" />
        </div>

        {/* Фазы вегетации */}
        <Card className="mt-3 p-4">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="text-[15px] font-bold text-tx">Фаза вегетации</h3>
              <p className="text-[11px] text-tx-sec">Жизненный цикл культуры</p>
            </div>
            <Tag tone="green">{PHASE_LABELS[gh.phase]}</Tag>
          </div>
          <PhaseStepper current={currentPhaseIdx} />
        </Card>

        {/* График */}
        <Card className="mt-3 p-4">
          <div className="mb-3 flex items-center justify-between gap-2">
            <div>
              <h3 className="text-[15px] font-bold text-tx">Микроклимат {periodLabel}</h3>
              <div className="mt-1 flex items-center gap-3 text-[11px]">
                <span className="flex items-center gap-1 font-semibold text-brand">
                  <span className="h-2 w-2 rounded-full bg-brand" /> Температура
                </span>
                <span className="flex items-center gap-1 font-semibold text-blue-500">
                  <span className="h-2 w-2 rounded-full bg-blue-500" /> Влажность
                </span>
              </div>
            </div>
          </div>

          <Segmented
            className="mb-3"
            value={period}
            onChange={setPeriod}
            options={[
              { value: "24h", label: "24 ч" },
              { value: "7d", label: "7 дн" },
              { value: "30d", label: "30 дн" },
            ]}
          />

          <div className="h-[200px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={data} margin={{ top: 5, right: 6, left: -22, bottom: 0 }}>
                <defs>
                  <linearGradient id="tempGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#2E7D32" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="#2E7D32" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-line)" vertical={false} />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 10, fill: "var(--color-tx-muted)" }}
                  axisLine={false}
                  tickLine={false}
                  interval="preserveStartEnd"
                />
                <YAxis
                  tick={{ fontSize: 10, fill: "var(--color-tx-muted)" }}
                  axisLine={false}
                  tickLine={false}
                  width={34}
                />
                <Tooltip content={<ChartTip period={period} />} />
                {showTarget && (
                  <ReferenceLine
                    y={25}
                    stroke="#F9A825"
                    strokeDasharray="5 4"
                    label={{ value: "цель 25°", fontSize: 9, fill: "#F9A825", position: "insideTopRight" }}
                  />
                )}
                <Area
                  type="monotone"
                  dataKey="temp"
                  stroke="#2E7D32"
                  strokeWidth={2.5}
                  fill="url(#tempGrad)"
                  dot={false}
                  activeDot={{ r: 4, fill: "#2E7D32" }}
                />
                <Line
                  type="monotone"
                  dataKey="humidity"
                  stroke="#3B82F6"
                  strokeWidth={2}
                  dot={false}
                  activeDot={{ r: 4, fill: "#3B82F6" }}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* Доп. информация о культуре */}
        <Card className="mt-3 p-4">
          <h3 className="text-[15px] font-bold text-tx">Параметры выращивания</h3>
          <div className="mt-3 space-y-2.5">
            <ParamRow label="Целевая температура" value={`${gh.tempTarget} °C`} ok={Math.abs(gh.temp - gh.tempTarget) < 1.5} />
            <ParamRow label="Оптимальная влажность" value="60–75 %" ok={gh.humidity >= 60 && gh.humidity <= 75} />
            <ParamRow label="Уровень CO₂" value="820 ppm" ok />
            <ParamRow label="Световой день" value="16 часов" ok />
          </div>
        </Card>
      </main>
    </div>
  );
}

// ---- Кастомный тултип графика ----
function ChartTip({ active, payload, label, period }: any) {
  if (!active || !payload?.length) return null;
  const temp = payload.find((p: any) => p.dataKey === "temp")?.value;
  const hum = payload.find((p: any) => p.dataKey === "humidity")?.value;
  const lbl = period === "24h" ? `${label}:00` : label;
  return (
    <div className="rounded-xl border border-line bg-surface px-3 py-2 shadow-soft">
      <p className="text-[10px] font-semibold text-tx-muted">{lbl}</p>
      {temp != null && (
        <p className="text-xs font-bold text-brand">{temp} °C</p>
      )}
      {hum != null && <p className="text-xs font-bold text-blue-500">{hum} %</p>}
    </div>
  );
}

// ---- Индикатор фаз вегетации ----
function PhaseStepper({ current }: { current: number }) {
  const progress = (current / (PHASE_ORDER.length - 1)) * 100;
  return (
    <div className="relative pt-2">
      {/* Линия прогресса */}
      <div className="absolute left-4 right-4 top-[26px] h-1 rounded-full bg-surface-3" />
      <div
        className="absolute left-4 top-[26px] h-1 rounded-full bg-brand transition-all duration-500"
        style={{ width: `calc(${progress}% - ${progress > 0 ? "16px" : "0px"})` }}
      />
      <div className="relative flex justify-between">
        {PHASE_ORDER.map((ph, i) => {
          const done = i < current;
          const active = i === current;
          return (
            <div key={ph} className="flex flex-col items-center gap-1.5" style={{ width: "25%" }}>
              <div
                className={cn(
                  "flex h-8 w-8 items-center justify-center rounded-full text-sm ring-4 ring-bg transition",
                  active ? "bg-brand" : done ? "bg-brand-light" : "bg-surface-3"
                )}
              >
                <span className={active || done ? "grayscale-0" : "opacity-50"}>{PHASE_ICONS[i]}</span>
              </div>
              <span
                className={cn(
                  "text-center text-[10px] font-semibold leading-tight",
                  active ? "text-brand" : "text-tx-sec"
                )}
              >
                {PHASE_LABELS[ph]}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ---- Мини-метрика ----
function MiniStat({
  icon: Icon,
  tint,
  value,
  unit,
}: {
  icon: typeof Thermometer;
  tint: string;
  value: string;
  unit: string;
}) {
  return (
    <Card className="flex flex-col items-center gap-1 p-2.5">
      <Icon className={cn("h-4 w-4", tint)} />
      <div className="flex items-baseline gap-0.5">
        <span className="text-base font-extrabold leading-none text-tx">{value}</span>
        <span className="text-[9px] font-semibold text-tx-sec">{unit}</span>
      </div>
    </Card>
  );
}

// ---- Строка параметра ----
function ParamRow({ label, value, ok }: { label: string; value: string; ok: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-[13px] text-tx-sec">{label}</span>
      <div className="flex items-center gap-2">
        <span className="text-[13px] font-bold text-tx">{value}</span>
        <span className={cn("h-2 w-2 rounded-full", ok ? "bg-brand" : "bg-amber")} />
      </div>
    </div>
  );
}
