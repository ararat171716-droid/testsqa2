import { useState } from "react";
import {
  ArrowRight,
  Cpu,
  Droplets,
  GraduationCap,
  Leaf,
  Smartphone,
  TrendingUp,
  Wifi,
} from "lucide-react";
import { useApp } from "../AppContext";
import { AUTHOR, THESIS } from "../data";
import { StatusBar } from "../components/ui";
import { cn } from "../utils/cn";

// ============================================================
// Экран 10 · ОНБОРДИНГ
// Слайд 0 — карточка с темой ВКР и автором (можно пропустить).
// Далее: концепция «управление с телефона», трёхуровневая
// архитектура и экономический эффект.
// ============================================================

type SlideKind = "thesis" | "concept" | "arch" | "effect";

interface Slide {
  kind: SlideKind;
  icon: typeof Smartphone;
  title: string;
  text: string;
  accent: string;
}

const SLIDES: Slide[] = [
  {
    kind: "thesis",
    icon: GraduationCap,
    title: "Выпускная квалификационная работа",
    text: "Приложение разработано как прикладное решение в рамках научно-практического исследования по цифровизации тепличного хозяйства.",
    accent: "from-brand-dark to-brand",
  },
  {
    kind: "concept",
    icon: Smartphone,
    title: "Управление теплицей с телефона",
    text: "Полный контроль микроклимата, полива и инженерных систем тепличного комплекса — прямо со смартфона, из любой точки мира.",
    accent: "from-brand-light to-brand",
  },
  {
    kind: "arch",
    icon: Cpu,
    title: "Трёхуровневая IoT-архитектура",
    text: "Датчики и исполнительные механизмы → беспроводной канал передачи данных → мобильное приложение управления и визуализации.",
    accent: "from-amber to-amber-light",
  },
  {
    kind: "effect",
    icon: TrendingUp,
    title: "Экономический эффект",
    text: "До 90 минут экономии в день на сотрудника, 307–500 тыс. руб/год эффекта и окупаемость за 1,5–3,1 года.",
    accent: "from-brand to-brand-dark",
  },
];

export function OnboardingScreen() {
  const { replace } = useApp();
  const [i, setI] = useState(0);
  const slide = SLIDES[i];
  const last = i === SLIDES.length - 1;
  const Icon = slide.icon;

  const next = () => (last ? replace("auth") : setI((v) => v + 1));

  return (
    <div className="flex h-full flex-col bg-bg">
      <StatusBar />
      {/* Кнопка «Пропустить» */}
      <div className="flex justify-end px-5 pt-1">
        <button
          onClick={() => replace("auth")}
          className="rounded-full px-3 py-1.5 text-sm font-semibold text-tx-sec transition hover:text-tx"
        >
          Пропустить
        </button>
      </div>

      {/* Иллюстрация слайда */}
      <div className="flex flex-1 flex-col items-center justify-center px-8">
        <div className="animate-scale-in flex flex-col items-center text-center">
          <div
            className={cn(
              "mb-8 flex h-44 w-44 items-center justify-center rounded-[2.5rem] bg-gradient-to-br shadow-soft",
              slide.accent
            )}
          >
            <Icon className="h-20 w-20 text-white" strokeWidth={1.6} />
          </div>
          <h2 className="text-[25px] font-extrabold leading-tight tracking-tight text-tx">
            {slide.title}
          </h2>
          <p className="mt-4 text-[15px] leading-relaxed text-tx-sec">{slide.text}</p>

          {/* === Карточка темы ВКР и автора (слайд 0) === */}
          {slide.kind === "thesis" && (
            <div className="mt-7 w-full max-w-[320px] rounded-3xl border border-line bg-surface p-5 text-left shadow-soft">
              <div className="flex items-center gap-2">
                <span className="rounded-md bg-amber px-1.5 py-0.5 text-[10px] font-extrabold text-[#0F1B12]">
                  ВКР
                </span>
                <span className="text-[11px] font-semibold text-tx-sec">Тема исследования</span>
              </div>
              <h3 className="mt-2.5 text-[15px] font-bold leading-snug text-tx">{THESIS.title}</h3>
              <p className="mt-1 text-[12px] leading-snug text-tx-sec">{THESIS.subtitle}</p>
              <div className="mt-4 flex items-center gap-3 border-t border-line pt-3.5">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-brand/12 text-xs font-extrabold text-brand">
                  {AUTHOR.initials}
                </div>
                <div>
                  <p className="text-[13px] font-bold text-tx">{AUTHOR.name}</p>
                  <p className="text-[11px] text-tx-sec">
                    {AUTHOR.course}, {AUTHOR.university}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* === Визуализация для слайда об архитектуре === */}
          {slide.kind === "arch" && (
            <div className="mt-7 flex items-center gap-2">
              {[
                { icon: Cpu, label: "Датчики" },
                { icon: Wifi, label: "Канал" },
                { icon: Smartphone, label: "Приложение" },
              ].map((s, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <div className="flex flex-col items-center gap-1.5">
                    <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-surface shadow-card">
                      <s.icon className="h-5 w-5 text-brand" />
                    </div>
                    <span className="text-[10px] font-semibold text-tx-sec">{s.label}</span>
                  </div>
                  {idx < 2 && <ArrowRight className="h-4 w-4 text-tx-muted" />}
                </div>
              ))}
            </div>
          )}

          {/* === Визуализация для слайда об эффекте === */}
          {slide.kind === "effect" && (
            <div className="mt-7 flex gap-3">
              {[
                { icon: TrendingUp, v: "500K", l: "₽ / год" },
                { icon: Droplets, v: "18%", l: "воды" },
                { icon: Leaf, v: "1,5 г", l: "окупаем." },
              ].map((s, idx) => (
                <div
                  key={idx}
                  className="flex w-20 flex-col items-center gap-1 rounded-2xl bg-surface p-3 shadow-card"
                >
                  <s.icon className="h-5 w-5 text-brand" />
                  <span className="text-base font-extrabold text-tx">{s.v}</span>
                  <span className="text-[10px] font-medium text-tx-sec">{s.l}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Навигация: точки + кнопка */}
      <div className="flex items-center justify-between px-8 pb-10 pt-4">
        <div className="flex gap-2">
          {SLIDES.map((_, idx) => (
            <span
              key={idx}
              className={cn(
                "h-2 rounded-full transition-all",
                idx === i ? "w-6 bg-brand" : "w-2 bg-surface-3"
              )}
            />
          ))}
        </div>
        <button
          onClick={next}
          className="flex items-center gap-2 rounded-full bg-brand px-6 py-3.5 text-sm font-bold text-white shadow-soft transition hover:bg-brand-dark active:scale-95"
        >
          {last ? "Начать работу" : "Далее"}
          <ArrowRight className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
