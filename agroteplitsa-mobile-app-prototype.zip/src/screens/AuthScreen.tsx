import { useState } from "react";
import {
  ChevronRight,
  Fingerprint,
  ShieldCheck,
  User,
} from "lucide-react";
import { useApp } from "../AppContext";
import { ROLES } from "../data";
import type { Role } from "../types";
import { Logo } from "../components/Logo";
import { StatusBar } from "../components/ui";
import { cn } from "../utils/cn";

// ============================================================
// Экран 1 · АВТОРИЗАЦИЯ
// Ввод имени и фамилии, выбор роли, биометрия,
// чекбокс «Запомнить меня». Введённое имя сохраняется
// в контексте и затем отображается в приложении.
// ============================================================
export function AuthScreen() {
  const { replace, setRole, role, setUserName } = useApp();
  const [firstName, setFirstName] = useState("Никита");
  const [lastName, setLastName] = useState("Шохин");
  const [remember, setRemember] = useState(true);

  // Вход: сохраняем имя + фамилию и переходим на дашборд
  const enter = () => {
    const name = `${firstName.trim()} ${lastName.trim()}`.trim();
    if (name) setUserName(name);
    replace("dashboard");
  };

  return (
    <div className="flex h-full flex-col bg-bg">
      <StatusBar />

      <div className="flex-1 overflow-y-auto thin-scroll px-6 pb-8">
        {/* Логотип и приветствие */}
        <div className="animate-fade-in flex flex-col items-center pt-4 text-center">
          <Logo size="lg" />
          <h1 className="mt-5 text-[22px] font-extrabold tracking-tight text-tx">
            Добро пожаловать!
          </h1>
          <p className="mt-1.5 text-sm text-tx-sec">
            Войдите для доступа к управлению теплицами
          </p>
        </div>

        {/* Выбор роли */}
        <div className="mt-7">
          <p className="mb-2.5 text-xs font-bold uppercase tracking-wide text-tx-muted">
            Ваша роль
          </p>
          <div className="grid grid-cols-3 gap-2.5">
            {ROLES.map((r) => {
              const active = role === r.id;
              return (
                <button
                  key={r.id}
                  onClick={() => setRole(r.id as Role)}
                  className={cn(
                    "flex flex-col items-center gap-1.5 rounded-2xl border p-3 transition active:scale-95",
                    active
                      ? "border-brand bg-brand/8 shadow-card"
                      : "border-line bg-surface hover:border-brand/40"
                  )}
                >
                  <div
                    className={cn(
                      "flex h-9 w-9 items-center justify-center rounded-full text-xs font-bold",
                      active ? "bg-brand text-white" : "bg-surface-2 text-tx-sec"
                    )}
                  >
                    {r.initials}
                  </div>
                  <span
                    className={cn(
                      "text-[11px] font-semibold leading-tight",
                      active ? "text-brand" : "text-tx-sec"
                    )}
                  >
                    {r.title}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Поля ввода: имя и фамилия */}
        <div className="mt-6 space-y-3.5">
          <Field icon={User} label="Имя">
            <input
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
              className="w-full bg-transparent text-[15px] font-medium text-tx outline-none placeholder:text-tx-muted"
              placeholder="Введите ваше имя"
            />
          </Field>
          <Field icon={User} label="Фамилия">
            <input
              value={lastName}
              onChange={(e) => setLastName(e.target.value)}
              className="w-full bg-transparent text-[15px] font-medium text-tx outline-none placeholder:text-tx-muted"
              placeholder="Введите вашу фамилию"
            />
          </Field>
        </div>

        {/* Запомнить меня */}
        <div className="mt-4 flex items-center justify-between">
          <button
            onClick={() => setRemember((v) => !v)}
            className="flex items-center gap-2.5"
          >
            <span
              className={cn(
                "flex h-5 w-5 items-center justify-center rounded-md border-2 transition",
                remember ? "border-brand bg-brand" : "border-surface-3 bg-transparent"
              )}
            >
              {remember && <ShieldCheck className="h-3.5 w-3.5 text-white" strokeWidth={3} />}
            </span>
            <span className="text-[13px] font-medium text-tx-sec">Запомнить меня</span>
          </button>
          <span className="text-[13px] font-medium text-tx-muted">Без пароля · демо</span>
        </div>

        {/* Кнопка входа */}
        <button
          onClick={enter}
          className="mt-7 flex w-full items-center justify-center gap-2 rounded-2xl bg-brand py-4 text-[15px] font-bold text-white shadow-soft transition hover:bg-brand-dark active:scale-[0.98]"
        >
          Войти в систему
          <ChevronRight className="h-5 w-5" />
        </button>

        {/* Биометрия */}
        <div className="mt-5 flex flex-col items-center gap-3">
          <div className="flex w-full items-center gap-4">
            <span className="h-px flex-1 bg-line" />
            <span className="text-xs font-medium text-tx-muted">или быстро</span>
            <span className="h-px flex-1 bg-line" />
          </div>
          <button
            onClick={enter}
            className="flex items-center gap-2.5 rounded-2xl border border-line bg-surface px-6 py-3 transition hover:border-brand/40 active:scale-95"
          >
            <Fingerprint className="h-6 w-6 text-brand" />
            <span className="text-sm font-semibold text-tx">Войти по Face ID / отпечатку</span>
          </button>
        </div>

        {/* Подсказка демо-доступа */}
        <p className="mt-6 text-center text-[11px] leading-relaxed text-tx-muted">
          Демо-доступ. Имя и фамилия предзаполнены —<br />измените их или нажмите «Войти».
        </p>
      </div>
    </div>
  );
}

/** Поле ввода с иконкой и подписью */
function Field({
  icon: Icon,
  label,
  children,
}: {
  icon: typeof User;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-line bg-surface px-4 py-3 transition focus-within:border-brand">
      <span className="text-[11px] font-semibold uppercase tracking-wide text-tx-muted">
        {label}
      </span>
      <div className="mt-0.5 flex items-center gap-2.5">
        <Icon className="h-5 w-5 shrink-0 text-tx-muted" />
        {children}
      </div>
    </div>
  );
}
