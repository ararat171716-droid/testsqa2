import { useState } from "react";
import {
  Aperture,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Image as ImageIcon,
  Move,
  Sparkles,
  Video,
  X,
  ZoomIn,
} from "lucide-react";
import { CAMERAS, GALLERY } from "../data";
import { BackHeader, BottomNav, Card, FullOverlay, StatusBar } from "../components/ui";
import { cn } from "../utils/cn";
import type { Camera as CameraT } from "../types";

// Фотографии теплиц (генерируются и инлайнятся в сборку)
import camCucumber from "../assets/cam-cucumber.jpg";
import camCucumber2 from "../assets/cam-cucumber2.jpg";
import camTomato from "../assets/cam-tomato.jpg";
import camSeedling from "../assets/cam-seedling.jpg";
import leafChlorosis from "../assets/leaf-chlorosis.jpg";

// Привязка изображений к камерам и галерее
const CAM_IMG: Record<string, string> = {
  c1: camCucumber,
  c2: camTomato,
  c3: camCucumber2,
  c4: camSeedling,
};
const GAL_IMG: Record<string, string> = {
  g1: leafChlorosis,
  g2: camTomato,
  g3: camSeedling,
  g4: camCucumber2,
};

// ============================================================
// Экран 6 · ВИЗУАЛЬНЫЙ МОНИТОРИНГ
// Сетка камер 2×2 с меткой LIVE, полноэкранный просмотр с PTZ,
// галерея фотофиксации с AI-метками.
// ============================================================

export function CamerasScreen() {
  const [active, setActive] = useState<CameraT | null>(null);

  return (
    <div className="flex h-full flex-col bg-bg">
      <StatusBar />
      <BackHeader title="Камеры" subtitle="Видеомониторинг и AI-анализ" />

      <main className="flex-1 overflow-y-auto thin-scroll px-4 pb-28">
        {/* Сетка камер 2×2 */}
        <div className="grid grid-cols-2 gap-2.5">
          {CAMERAS.map((c) => (
            <button
              key={c.id}
              onClick={() => c.live && setActive(c)}
              className="relative aspect-square overflow-hidden rounded-2xl border border-line bg-surface-2 text-left shadow-card transition active:scale-[0.97]"
            >
              <img
                src={CAM_IMG[c.id]}
                alt={c.name}
                className={cn("h-full w-full object-cover", !c.live && "opacity-40 grayscale")}
              />
              {/* LIVE-метка */}
              <div className="absolute left-2 top-2 flex items-center gap-1 rounded-full bg-black/55 px-2 py-0.5 backdrop-blur-sm">
                {c.live ? (
                  <>
                    <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-red-500" />
                    <span className="text-[9px] font-bold tracking-wide text-white">LIVE</span>
                  </>
                ) : (
                  <span className="text-[9px] font-bold text-white/70">НЕТ СИГНАЛА</span>
                )}
              </div>
              {/* AI-индикатор */}
              {c.live && (
                <div className="absolute right-2 top-2 flex items-center gap-0.5 rounded-full bg-amber/90 px-1.5 py-0.5">
                  <Sparkles className="h-2.5 w-2.5 text-[#0F1B12]" />
                  <span className="text-[8px] font-bold text-[#0F1B12]">AI</span>
                </div>
              )}
              {/* Низ: подпись */}
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/75 to-transparent p-2 pt-6">
                <p className="text-xs font-bold text-white">{c.greenhouse}</p>
                <p className="truncate text-[10px] text-white/75">{c.name}</p>
              </div>
            </button>
          ))}
        </div>

        {/* Галерея фотофиксации */}
        <div className="mb-2 mt-6 flex items-center gap-2">
          <ImageIcon className="h-4 w-4 text-tx-sec" />
          <h2 className="text-[15px] font-bold text-tx">Галерея и AI-анализ</h2>
        </div>

        <div className="space-y-2.5">
          {GALLERY.map((g) => (
            <Card key={g.id} className="flex gap-3 overflow-hidden p-2.5">
              <div className="h-[72px] w-[72px] shrink-0 overflow-hidden rounded-xl">
                <img src={GAL_IMG[g.id]} alt={g.title} className="h-full w-full object-cover" />
              </div>
              <div className="min-w-0 flex-1 py-0.5">
                <div className="flex items-center justify-between gap-2">
                  <p className="truncate text-[13px] font-bold text-tx">{g.title}</p>
                  <span className="shrink-0 text-[10px] text-tx-muted">{g.date}</span>
                </div>
                <div
                  className={cn(
                    "mt-1.5 flex items-start gap-1.5 rounded-lg p-1.5",
                    g.level === "critical"
                      ? "bg-red-500/10"
                      : g.level === "warning"
                      ? "bg-amber/12"
                      : "bg-brand/10"
                  )}
                >
                  {g.level === "ok" ? (
                    <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand" />
                  ) : (
                    <Sparkles
                      className={cn(
                        "mt-0.5 h-3.5 w-3.5 shrink-0",
                        g.level === "critical" ? "text-red-500" : "text-amber"
                      )}
                    />
                  )}
                  <p
                    className={cn(
                      "text-[11px] font-medium leading-snug",
                      g.level === "critical" ? "text-red-500" : g.level === "warning" ? "text-amber" : "text-brand"
                    )}
                  >
                    {g.ai}
                  </p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </main>

      {/* Полноэкранный просмотр */}
      <CameraViewer cam={active} onClose={() => setActive(null)} />

      <BottomNav />
    </div>
  );
}

// ---- Полноэкранный просмотр камеры с PTZ ----
function CameraViewer({ cam, onClose }: { cam: CameraT | null; onClose: () => void }) {
  const [rec, setRec] = useState(false);

  return (
    <FullOverlay open={!!cam}>
      {cam && (
        <div className="flex h-full flex-col">
          {/* Изображение */}
          <div className="relative flex-1">
            <img src={CAM_IMG[cam.id]} alt={cam.name} className="h-full w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black/70" />

            {/* Верхняя панель */}
            <div className="absolute inset-x-0 top-0 flex items-center justify-between p-4 pt-12">
              <div className="flex items-center gap-2">
                <span className="flex items-center gap-1 rounded-full bg-red-600 px-2 py-0.5">
                  <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" />
                  <span className="text-[10px] font-bold text-white">LIVE</span>
                </span>
                {rec && (
                  <span className="flex items-center gap-1 rounded-full bg-red-600 px-2 py-0.5">
                    <span className="h-2 w-2 rounded-full bg-white" />
                    <span className="text-[10px] font-bold text-white">REC 00:08</span>
                  </span>
                )}
              </div>
              <button
                onClick={onClose}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-black/50 text-white backdrop-blur-sm transition active:scale-90"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* AI-баннер */}
            <div className="absolute inset-x-4 bottom-4">
              <div className="flex items-center gap-2 rounded-2xl bg-black/55 p-3 backdrop-blur-md">
                <Sparkles className="h-5 w-5 shrink-0 text-amber" />
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-wide text-amber">AI-анализ кадра</p>
                  <p className="text-xs text-white">{cam.ai}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Нижняя панель управления */}
          <div className="shrink-0 bg-[#0F1B12] px-5 pb-8 pt-4">
            {/* PTZ-управление */}
            <div className="mb-4 flex items-center justify-between">
              <div className="flex flex-col items-center gap-1">
                <span className="text-[10px] font-semibold text-white/60">PTZ-управление</span>
                <div className="relative h-24 w-24">
                  <PTZBtn className="left-1/2 top-0 -translate-x-1/2">
                    <ChevronUp className="h-5 w-5" />
                  </PTZBtn>
                  <PTZBtn className="bottom-0 left-1/2 -translate-x-1/2">
                    <ChevronDown className="h-5 w-5" />
                  </PTZBtn>
                  <PTZBtn className="left-0 top-1/2 -translate-y-1/2">
                    <ChevronLeft className="h-5 w-5" />
                  </PTZBtn>
                  <PTZBtn className="right-0 top-1/2 -translate-y-1/2">
                    <ChevronRight className="h-5 w-5" />
                  </PTZBtn>
                  <button className="absolute left-1/2 top-1/2 flex h-9 w-9 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-brand/30 text-white">
                    <Move className="h-4 w-4" />
                  </button>
                </div>
              </div>

              {/* Зум */}
              <div className="flex flex-col items-center gap-2">
                <span className="text-[10px] font-semibold text-white/60">Зум</span>
                <div className="flex flex-col gap-1.5">
                  <button className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/10 text-white transition active:scale-90">
                    <ZoomIn className="h-4 w-4" />
                  </button>
                  <button className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/10 text-white transition active:scale-90">
                    <span className="text-sm font-bold">−</span>
                  </button>
                </div>
              </div>

              {/* Действия */}
              <div className="flex flex-col gap-2">
                <ActionBtn icon={Aperture} label="Фото" tone="white" />
                <ActionBtn icon={Video} label={rec ? "Стоп" : "Видео"} tone={rec ? "red" : "white"} onClick={() => setRec((v) => !v)} />
              </div>
            </div>
          </div>
        </div>
      )}
    </FullOverlay>
  );
}

function PTZBtn({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <button
      className={cn(
        "absolute flex h-8 w-8 items-center justify-center rounded-lg bg-white/10 text-white backdrop-blur-sm transition active:scale-90 active:bg-brand",
        className
      )}
    >
      {children}
    </button>
  );
}

function ActionBtn({
  icon: Icon,
  label,
  tone,
  onClick,
}: {
  icon: typeof Aperture;
  label: string;
  tone: "white" | "red";
  onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex w-16 flex-col items-center gap-1 rounded-xl py-2 text-white transition active:scale-90",
        tone === "red" ? "bg-red-600" : "bg-white/10"
      )}
    >
      <Icon className="h-5 w-5" />
      <span className="text-[10px] font-semibold">{label}</span>
    </button>
  );
}
