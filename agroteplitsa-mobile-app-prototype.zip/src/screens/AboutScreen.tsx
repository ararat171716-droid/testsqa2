import {
  ArrowRight,
  CheckCircle2,
  Clock,
  Cpu,
  GraduationCap,
  Leaf,
  MapPin,
  Smartphone,
  TrendingUp,
  Wifi,
} from "lucide-react";
import { AUTHOR, ECONOMICS, THESIS } from "../data";
import { BackHeader, Card, StatusBar } from "../components/ui";
import { Logo } from "../components/Logo";

// ============================================================
// Экран · О ПРИЛОЖЕНИИ (научное обоснование)
// Положения диссертационного исследования и трёхуровневая
// архитектура IoT.
// ============================================================

const LEVELS = [
  {
    icon: Cpu,
    title: "Уровень 1 · Датчики и ИМ",
    desc: "IoT-датчики микроклимата (температура, влажность, освещённость, влага почвы) и исполнительные механизмы (фрамуги, полив, досветка).",
  },
  {
    icon: Wifi,
    title: "Уровень 2 · Канал связи",
    desc: "Беспроводной канал передачи данных (Zigbee / LoRaWAN) с энергонезависимым шлюзом и резервированием.",
  },
  {
    icon: Smartphone,
    title: "Уровень 3 · Приложение",
    desc: "Мобильное приложение управления и визуализации — текущий продукт, обеспечивающий оперативный контроль и аналитику.",
  },
];

const THESES = [
  { icon: Clock, value: "53–90 мин", label: "в день на сотрудника", note: "233–396 часов в год" },
  { icon: TrendingUp, value: `${ECONOMICS.effect}`, label: "тыс. руб/год эффекта", note: "совокупный экономический эффект" },
  { icon: CheckCircle2, value: `${ECONOMICS.payback} года`, label: "срок окупаемости", note: `внедрение ${ECONOMICS.investment} тыс. ₽` },
];

export function AboutScreen() {
  return (
    <div className="flex h-full flex-col bg-bg">
      <StatusBar />
      <BackHeader title="О приложении" subtitle="Научное обоснование" />

      <main className="flex-1 overflow-y-auto thin-scroll px-4 pb-28">
        {/* Шапка с логотипом */}
        <Card className="overflow-hidden p-0">
          <div className="bg-gradient-to-br from-brand to-brand-dark p-5">
            <div className="flex items-center gap-3">
              <Logo size="md" />
              <div>
                <h2 className="text-lg font-extrabold leading-tight text-white">
                  АгроТеплица<span className="text-amber-light">.Контроль</span>
                </h2>
                <p className="text-xs text-white/80">Умная теплица в вашем кармане</p>
              </div>
            </div>
            <p className="mt-3 text-[13px] leading-relaxed text-white/90">
              Мобильная система удалённого управления тепличным комплексом —
              третий, визуализационно-управляющий уровень IoT-архитектуры
              овощеводческого предприятия.
            </p>
          </div>
          <div className="flex items-center gap-2 p-3.5">
            <MapPin className="h-4 w-4 shrink-0 text-brand" />
            <p className="text-xs text-tx-sec">
              Кейс: УНПК «Агроцентр» и АО «Совхоз-Весна», Саратовская область
            </p>
          </div>
        </Card>

        {/* Трёхуровневая архитектура */}
        <h3 className="mb-2 mt-5 px-1 text-[13px] font-bold uppercase tracking-wide text-tx-sec">
          Архитектура решения
        </h3>
        <div className="space-y-2">
          {LEVELS.map((l, i) => (
            <div key={i}>
              <Card className="flex items-start gap-3 p-3.5">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand/12">
                  <l.icon className="h-5 w-5 text-brand" />
                </div>
                <div className="flex-1">
                  <p className="text-[13px] font-bold text-tx">{l.title}</p>
                  <p className="mt-0.5 text-[12px] leading-snug text-tx-sec">{l.desc}</p>
                </div>
              </Card>
              {i < LEVELS.length - 1 && (
                <div className="flex justify-center py-0.5">
                  <ArrowRight className="h-4 w-4 rotate-90 text-tx-muted" />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Научное обоснование (диссертация) */}
        <div className="mb-2 mt-5 flex items-center gap-2 px-1">
          <GraduationCap className="h-4 w-4 text-brand" />
          <h3 className="text-[13px] font-bold uppercase tracking-wide text-tx-sec">
            Научное обоснование
          </h3>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {THESES.map((t, i) => (
            <Card key={i} className="p-3 text-center">
              <t.icon className="mx-auto h-5 w-5 text-brand" />
              <p className="mt-1.5 text-[15px] font-extrabold leading-tight text-tx">{t.value}</p>
              <p className="mt-0.5 text-[10px] font-semibold leading-tight text-tx-sec">{t.label}</p>
              <p className="mt-1 text-[9px] leading-tight text-tx-muted">{t.note}</p>
            </Card>
          ))}
        </div>

        <Card className="mt-3 gap-2 p-4">
          <div className="flex items-start gap-2.5">
            <Leaf className="mt-0.5 h-5 w-5 shrink-0 text-brand" />
            <p className="text-[13px] leading-relaxed text-tx">
              Приложение реализует положения диссертационного исследования:
              сокращение рутинных операций на{" "}
              <span className="font-bold text-brand">53–90 минут в день</span> на сотрудника
              (233–396 часов в год), ежегодный экономический эффект{" "}
              <span className="font-bold text-brand">307–500 тыс. руб.</span> и срок окупаемости{" "}
              <span className="font-bold text-brand">1,5–3,1 года</span>.
            </p>
          </div>
        </Card>

        {/* Карточка темы ВКР */}
        <div className="mb-2 mt-5 flex items-center gap-2 px-1">
          <GraduationCap className="h-4 w-4 text-brand" />
          <h3 className="text-[13px] font-bold uppercase tracking-wide text-tx-sec">
            Выпускная квалификационная работа
          </h3>
        </div>
        <Card className="overflow-hidden p-0">
          <div className="bg-gradient-to-br from-brand-dark to-brand p-4">
            <div className="flex items-center gap-2">
              <span className="rounded-md bg-amber px-1.5 py-0.5 text-[10px] font-extrabold text-[#0F1B12]">
                ВКР
              </span>
              <span className="text-[11px] font-semibold text-white/75">
                Тема исследования
              </span>
            </div>
            <h4 className="mt-2 text-[14px] font-bold leading-snug text-white">
              {THESIS.title}
            </h4>
            <p className="mt-1 text-[12px] leading-snug text-white/80">
              {THESIS.subtitle}
            </p>
          </div>
          {/* Автор */}
          <div className="flex items-center gap-3 p-4">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-brand/12 text-sm font-extrabold text-brand">
              {AUTHOR.initials}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-[14px] font-bold text-tx">{AUTHOR.name}</p>
              <p className="text-[11px] text-tx-sec">
                {AUTHOR.course} · {AUTHOR.university}
              </p>
            </div>
          </div>
        </Card>

        <p className="mt-4 px-2 text-center text-[11px] leading-relaxed text-tx-muted">
          Разработано как часть научно-практической работы по цифровизации
          тепличного хозяйства. Все данные — демонстрационные.
        </p>
      </main>
    </div>
  );
}
