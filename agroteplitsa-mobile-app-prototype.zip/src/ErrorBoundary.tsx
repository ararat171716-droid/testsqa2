import { Component, type ErrorInfo, type ReactNode } from "react";

// ============================================================
// ErrorBoundary — перехватчик ошибок рендеринга.
// Если приложение падает, вместо белого экрана показывает
// понятное сообщение с текстом ошибки (помогает диагностировать).
// ============================================================

interface State {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends Component<{ children: ReactNode }, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    // Выводим ошибку в консоль для разработчика
    console.error("Ошибка рендеринга:", error, info);
  }

  reload = () => {
    location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div
          style={{
            minHeight: "100vh",
            padding: "32px 20px",
            fontFamily: "system-ui, sans-serif",
            background: "#0F1B12",
            color: "#eaf2ec",
          }}
        >
          <h1 style={{ fontSize: 20, marginBottom: 8 }}>
            ⚠️ Приложение упало с ошибкой
          </h1>
          <p style={{ color: "#9cb3a2", marginBottom: 20 }}>
            Это не белый экран — это значит, что ошибка найдена. Скопируй текст
            ниже и пришли мне:
          </p>
          <pre
            style={{
              background: "#243527",
              padding: 16,
              borderRadius: 12,
              overflow: "auto",
              fontSize: 13,
              whiteSpace: "pre-wrap",
              wordBreak: "break-word",
              color: "#fbc02d",
            }}
          >
            {this.state.error?.name}: {this.state.error?.message}
            {this.state.error?.stack ? "\n\n" + this.state.error.stack : ""}
          </pre>
          <button
            onClick={this.reload}
            style={{
              marginTop: 20,
              padding: "12px 24px",
              background: "#2E7D32",
              color: "#fff",
              border: "none",
              borderRadius: 12,
              fontSize: 15,
              fontWeight: 700,
              cursor: "pointer",
            }}
          >
            Перезапустить
          </button>
          <p style={{ marginTop: 24, color: "#6f8478", fontSize: 13 }}>
            Если выше написано что-то про <b>CORS</b>, <b>file://</b> или{" "}
            <b>module</b> — значит ты открываешь файл напрямую. Нужно запускать
            через терминал: <code>npm run dev</code> и открывать{" "}
            <code>localhost:5173</code>.
          </p>
        </div>
      );
    }
    return this.props.children;
  }
}
