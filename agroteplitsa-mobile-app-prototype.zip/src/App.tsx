import {
  Maximize2,
  Moon,
  RotateCcw,
  Sun,
} from "lucide-react";
import { AppProvider, useApp, type ScreenId } from "./AppContext";
import { SplashScreen } from "./screens/SplashScreen";
import { OnboardingScreen } from "./screens/OnboardingScreen";
import { AuthScreen } from "./screens/AuthScreen";
import { DashboardScreen } from "./screens/DashboardScreen";
import { ControlScreen } from "./screens/ControlScreen";
import { GreenhouseDetailScreen } from "./screens/GreenhouseDetailScreen";
import { ResourcesScreen } from "./screens/ResourcesScreen";
import { CamerasScreen } from "./screens/CamerasScreen";
import { NotificationsScreen } from "./screens/NotificationsScreen";
import { AnalyticsScreen } from "./screens/AnalyticsScreen";
import { SettingsScreen } from "./screens/SettingsScreen";
import { AboutScreen } from "./screens/AboutScreen";
import { SummaryScreen } from "./screens/SummaryScreen";
import { cn } from "./utils/cn";

// ============================================================
// Реестр экранов прототипа
// ============================================================
const SCREENS: Record<ScreenId, React.ComponentType<any>> = {
  splash: SplashScreen,
  onboarding: OnboardingScreen,
  auth: AuthScreen,
  dashboard: DashboardScreen,
  control: ControlScreen,
  greenhouse: GreenhouseDetailScreen,
  resources: ResourcesScreen,
  cameras: CamerasScreen,
  notifications: NotificationsScreen,
  analytics: AnalyticsScreen,
  settings: SettingsScreen,
  about: AboutScreen,
  summary: SummaryScreen,
};

function PhoneShell() {
  const { current, theme, stack, reset, navigate, toggleTheme } = useApp();
  const Screen = SCREENS[current.screen];

  return (
    // Полноэкранный контейнер с мобильной шириной по центру
    <div className="relative flex min-h-[100dvh] w-full justify-center bg-[#0a140e]">
      {/* Плавающая панель управления (по краям на широком экране) */}
      <div className="absolute right-5 top-5 z-20 hidden flex-col gap-2 sm:flex">
        <DemoBtn title="Светлая/тёмная тема" onClick={toggleTheme}>
          {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </DemoBtn>
        <DemoBtn title="Сводный экран защиты" onClick={() => navigate("summary")}>
          <Maximize2 className="h-4 w-4" />
        </DemoBtn>
        <DemoBtn title="Перезапуск" onClick={() => reset("splash")}>
          <RotateCcw className="h-4 w-4" />
        </DemoBtn>
      </div>

      {/* Рабочая область приложения на весь экран */}
      <div
        className={cn(
          "relative flex h-[100dvh] w-full max-w-[460px] flex-col overflow-hidden bg-bg",
          theme === "dark" && "dark"
        )}
      >
        {/* Активный экран с анимацией перехода */}
        <div key={`${stack.length}-${current.screen}`} className="animate-fade-in h-full w-full">
          <Screen params={current.params} />
        </div>
      </div>
    </div>
  );
}

function DemoBtn({
  children,
  onClick,
  title,
}: {
  children: React.ReactNode;
  onClick: () => void;
  title: string;
}) {
  return (
    <button
      title={title}
      onClick={onClick}
      className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/15 bg-white/10 text-white/90 backdrop-blur-md transition hover:bg-white/20 active:scale-90"
    >
      {children}
    </button>
  );
}

export default function App() {
  return (
    <AppProvider>
      <PhoneShell />
    </AppProvider>
  );
}
