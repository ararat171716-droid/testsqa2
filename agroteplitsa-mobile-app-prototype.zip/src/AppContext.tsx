import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import type { Notification, Role } from "./types";
import { NOTIFICATIONS } from "./data";

// ============================================================
// Идентификаторы всех экранов прототипа
// ============================================================
export type ScreenId =
  | "splash"
  | "onboarding"
  | "auth"
  | "dashboard"
  | "control"
  | "resources"
  | "cameras"
  | "notifications"
  | "greenhouse"
  | "analytics"
  | "settings"
  | "about"
  | "summary";

/** Вкладки нижней навигации */
export const TAB_SCREENS: ScreenId[] = [
  "dashboard",
  "control",
  "resources",
  "cameras",
  "notifications",
];

interface NavEntry {
  screen: ScreenId;
  params?: Record<string, string>;
}

/** Состояние блока управления инженерными системами (Экран 3) */
export interface ControlState {
  lighting: Record<string, boolean>; // вкл/выкл по теплицам
  intensity: number; // интенсивность досветки, %
  vents: number; // угол наклона фрамуг, °
  irrigation: boolean; // капельный полив
  irrigationMin: number; // длительность, мин
  nutrientProgram: 1 | 2 | 3; // программа питательного раствора
  ec: number; // электропроводность, мСм/см
  ph: number; // кислотность
  emergency: boolean;
}

interface AppContextValue {
  // Навигация
  stack: NavEntry[];
  current: NavEntry;
  navigate: (screen: ScreenId, params?: Record<string, string>) => void;
  replace: (screen: ScreenId, params?: Record<string, string>) => void;
  back: () => void;
  reset: (screen: ScreenId) => void;
  // Тема
  theme: "light" | "dark";
  toggleTheme: () => void;
  // Роль
  role: Role;
  setRole: (r: Role) => void;
  // Имя пользователя (вводится на экране авторизации)
  userName: string;
  setUserName: (name: string) => void;
  // Уведомления
  notifications: Notification[];
  markRead: (id: string) => void;
  markAllRead: () => void;
  unreadCount: number;
  // Состояние управления
  control: ControlState;
  setControl: (updater: (prev: ControlState) => ControlState) => void;
  // Язык
  lang: "RU" | "EN";
  setLang: (l: "RU" | "EN") => void;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [stack, setStack] = useState<NavEntry[]>([{ screen: "splash" }]);
  const [theme, setTheme] = useState<"light" | "dark">("light");
  const [role, setRole] = useState<Role>("agronomist");
  const [userName, setUserName] = useState<string>("Никита Шохин");
  const [notifications, setNotifications] = useState<Notification[]>(NOTIFICATIONS);
  const [lang, setLang] = useState<"RU" | "EN">("RU");

  // Начальное состояние управления
  const [control, setControlState] = useState<ControlState>({
    lighting: { gh1: true, gh2: false, gh3: true, seed: true },
    intensity: 75,
    vents: 35,
    irrigation: false,
    irrigationMin: 18,
    nutrientProgram: 1,
    ec: 2.4,
    ph: 6.2,
    emergency: false,
  });

  const current = stack[stack.length - 1];

  const navigate = useCallback(
    (screen: ScreenId, params?: Record<string, string>) => {
      setStack((s) => [...s, { screen, params }]);
    },
    []
  );

  const replace = useCallback(
    (screen: ScreenId, params?: Record<string, string>) => {
      setStack((s) => [...s.slice(0, -1), { screen, params }]);
    },
    []
  );

  const back = useCallback(() => {
    setStack((s) => (s.length > 1 ? s.slice(0, -1) : s));
  }, []);

  const reset = useCallback((screen: ScreenId) => {
    setStack([{ screen }]);
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme((t) => (t === "light" ? "dark" : "light"));
  }, []);

  const setControl = useCallback(
    (updater: (prev: ControlState) => ControlState) => {
      setControlState((prev) => updater(prev));
    },
    []
  );

  const markRead = useCallback((id: string) => {
    setNotifications((list) =>
      list.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  }, []);

  const markAllRead = useCallback(() => {
    setNotifications((list) => list.map((n) => ({ ...n, read: true })));
  }, []);

  const unreadCount = useMemo(
    () => notifications.filter((n) => !n.read).length,
    [notifications]
  );

  const value: AppContextValue = {
    stack,
    current,
    navigate,
    replace,
    back,
    reset,
    theme,
    toggleTheme,
    role,
    setRole,
    userName,
    setUserName,
    notifications,
    markRead,
    markAllRead,
    unreadCount,
    control,
    setControl,
    lang,
    setLang,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

// eslint-disable-next-line react-refresh/only-export-components
export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
