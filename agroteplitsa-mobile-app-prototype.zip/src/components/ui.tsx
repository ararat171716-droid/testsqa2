import type { ReactNode } from "react";
import {
  Bell,
  Camera,
  ChevronLeft,
  Droplets,
  Home,
  SlidersHorizontal,
} from "lucide-react";
import { cn } from "../utils/cn";
import { useApp, TAB_SCREENS, type ScreenId } from "../AppContext";

// ============================================================
// СТАТУС-БАР — отключён по запросу (время/Wi-Fi/заряд скрыты).
// Оставлен только тонкий отступ сверху, чтобы контент не
// прилипал к краю экрана (safe-area).
// ============================================================
export function StatusBar({ tone = "dark" }: { tone?: "dark" | "light" }) {
  void tone; // параметр сохранён для совместимости вызовов
  return <div className="h-3 shrink-0" />;
}

// ============================================================
// НИЖНЯЯ НАВИГАЦИЯ (5 вкладок)
// ============================================================
const TABS: { id: ScreenId; label: string; icon: typeof Home }[] = [
  { id: "dashboard", label: "Дашборд", icon: Home },
  { id: "control", label: "Управление", icon: SlidersHorizontal },
  { id: "resources", label: "Ресурсы", icon: Droplets },
  { id: "cameras", label: "Камеры", icon: Camera },
  { id: "notifications", label: "Сигналы", icon: Bell },
];

export function BottomNav() {
  const { current, reset, unreadCount } = useApp();
  const active = TAB_SCREENS.includes(current.screen) ? current.screen : null;

  return (
    <nav className="glass shrink-0 border-t border-line/60 px-2 pb-6 pt-2">
      <div className="flex items-stretch justify-between">
        {TABS.map((tab) => {
          const isActive = active === tab.id;
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => reset(tab.id)}
              className="group relative flex flex-1 flex-col items-center gap-1 py-1 transition active:scale-90"
            >
              <span
                className={cn(
                  "relative flex h-8 w-12 items-center justify-center rounded-full transition-colors",
                  isActive ? "bg-brand/12" : "bg-transparent group-hover:bg-surface-2"
                )}
              >
                <Icon
                  className={cn(
                    "h-[22px] w-[22px] transition-colors",
                    isActive ? "text-brand" : "text-tx-sec"
                  )}
                  strokeWidth={isActive ? 2.5 : 2}
                />
                {/* Бейдж непрочитанных уведомлений */}
                {tab.id === "notifications" && unreadCount > 0 && (
                  <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-1 text-[10px] font-bold text-white">
                    {unreadCount}
                  </span>
                )}
              </span>
              <span
                className={cn(
                  "text-[10px] font-semibold leading-none transition-colors",
                  isActive ? "text-brand" : "text-tx-sec"
                )}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}

// ============================================================
// ШАПКА С КНОПКОЙ НАЗАД
// ============================================================
export function BackHeader({
  title,
  subtitle,
  right,
  tone = "dark",
}: {
  title: string;
  subtitle?: string;
  right?: ReactNode;
  tone?: "dark" | "light";
}) {
  const { back } = useApp();
  const light = tone === "light";
  return (
    <header className={cn("flex items-center gap-3 px-4 pb-3 pt-1", light && "text-white")}>
      <button
        onClick={back}
        className={cn(
          "flex h-10 w-10 shrink-0 items-center justify-center rounded-full transition active:scale-90",
          light ? "bg-white/15 hover:bg-white/25" : "bg-surface-2 hover:bg-surface-3"
        )}
      >
        <ChevronLeft className={cn("h-6 w-6", light ? "text-white" : "text-tx")} />
      </button>
      <div className="min-w-0 flex-1">
        <h1 className="truncate text-[19px] font-bold leading-tight">{title}</h1>
        {subtitle && (
          <p className={cn("truncate text-xs", light ? "text-white/75" : "text-tx-sec")}>
            {subtitle}
          </p>
        )}
      </div>
      {right}
    </header>
  );
}

// ============================================================
// КАРТОЧКА
// ============================================================
export function Card({
  children,
  className,
  onClick,
}: {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
}) {
  return (
    <div
      onClick={onClick}
      className={cn(
        "rounded-3xl border border-line bg-surface shadow-card transition",
        onClick && "cursor-pointer hover:border-brand/40 hover:shadow-soft active:scale-[0.99]",
        className
      )}
    >
      {children}
    </div>
  );
}

// ============================================================
// ПЕРЕКЛЮЧАТЕЛЬ (тумблер)
// ============================================================
export function Toggle({
  checked,
  onChange,
  disabled,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      disabled={disabled}
      onClick={() => !disabled && onChange(!checked)}
      className={cn(
        "relative h-[30px] w-[52px] shrink-0 rounded-full transition-colors duration-200 disabled:opacity-40",
        checked ? "bg-brand" : "bg-surface-3"
      )}
    >
      <span
        className={cn(
          "absolute top-1/2 h-[24px] w-[24px] -translate-y-1/2 rounded-full bg-white shadow-md transition-all duration-200",
          checked ? "left-[calc(100%-26px)]" : "left-[3px]"
        )}
      />
    </button>
  );
}

// ============================================================
// СЕГМЕНТНЫЙ КОНТРОЛЬ
// ============================================================
export function Segmented<T extends string>({
  options,
  value,
  onChange,
  className,
}: {
  options: { value: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
  className?: string;
}) {
  return (
    <div className={cn("flex rounded-full bg-surface-2 p-1", className)}>
      {options.map((o) => (
        <button
          key={o.value}
          onClick={() => onChange(o.value)}
          className={cn(
            "flex-1 rounded-full px-2 py-1.5 text-xs font-semibold transition active:scale-95",
            value === o.value
              ? "bg-surface text-tx shadow-sm"
              : "text-tx-sec hover:text-tx"
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

// ============================================================
// ИНДИКАТОР СТАТУСА (точка)
// ============================================================
export function StatusDot({
  status,
  className,
}: {
  status: "ok" | "warning" | "critical";
  className?: string;
}) {
  const color =
    status === "ok" ? "bg-brand" : status === "warning" ? "bg-amber" : "bg-red-500";
  return (
    <span
      className={cn(
        "inline-block h-2.5 w-2.5 shrink-0 rounded-full",
        color,
        status !== "ok" && "animate-pulse",
        className
      )}
    />
  );
}

// ============================================================
// ПРОГРЕСС-БАР
// ============================================================
export function ProgressBar({
  value,
  className,
  barClassName,
}: {
  value: number;
  className?: string;
  barClassName?: string;
}) {
  return (
    <div className={cn("h-2 w-full overflow-hidden rounded-full bg-surface-3", className)}>
      <div
        className={cn("h-full rounded-full bg-brand transition-all duration-500", barClassName)}
        style={{ width: `${Math.min(100, Math.max(0, value))}%` }}
      />
    </div>
  );
}

// ============================================================
// СЛАЙДЕР (кастомный, с заливкой трека)
// ============================================================
export function Slider({
  value,
  min = 0,
  max = 100,
  step = 1,
  onChange,
  accent = "var(--color-brand)",
  disabled,
}: {
  value: number;
  min?: number;
  max?: number;
  step?: number;
  onChange: (v: number) => void;
  accent?: string;
  disabled?: boolean;
}) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div className={cn("relative flex h-8 items-center", disabled && "opacity-40")}>
      <div className="absolute h-2 w-full rounded-full bg-surface-3" />
      <div
        className="absolute h-2 rounded-full"
        style={{ width: `${pct}%`, background: accent }}
      />
      <div
        className="pointer-events-none absolute h-5 w-5 rounded-full border border-line bg-white shadow-md"
        style={{ left: `calc(${pct}% - 10px)` }}
      />
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        disabled={disabled}
        onChange={(e) => onChange(Number(e.target.value))}
        className="absolute inset-0 w-full cursor-pointer opacity-0"
      />
    </div>
  );
}

// ============================================================
// БЭЙДЖ / ТЕГ
// ============================================================
export function Tag({
  children,
  tone = "neutral",
  className,
}: {
  children: ReactNode;
  tone?: "neutral" | "green" | "amber" | "red" | "blue";
  className?: string;
}) {
  const tones = {
    neutral: "bg-surface-2 text-tx-sec",
    green: "bg-brand/12 text-brand",
    amber: "bg-amber/15 text-amber",
    red: "bg-red-500/12 text-red-500",
    blue: "bg-blue-500/12 text-blue-500",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-semibold",
        tones[tone],
        className
      )}
    >
      {children}
    </span>
  );
}

// ============================================================
// ВСПЛЫВАЮЩАЯ ПАНЕЛЬ (нижний sheet) и полноэкранный оверлей
// ============================================================
export function Sheet({
  open,
  onClose,
  children,
}: {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
}) {
  if (!open) return null;
  return (
    <div className="absolute inset-0 z-50 flex flex-col justify-end">
      <div
        className="absolute inset-0 animate-fade-in bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      />
      <div className="animate-slide-up relative max-h-[88%] overflow-y-auto thin-scroll rounded-t-[28px] border-t border-line bg-surface pb-8">
        <div className="sticky top-0 flex justify-center bg-surface py-3">
          <span className="h-1.5 w-10 rounded-full bg-surface-3" />
        </div>
        {children}
      </div>
    </div>
  );
}

export function FullOverlay({
  open,
  children,
}: {
  open: boolean;
  children: ReactNode;
}) {
  if (!open) return null;
  return (
    <div className="animate-fade-in absolute inset-0 z-50 bg-black">{children}</div>
  );
}
