import { Leaf } from "lucide-react";
import { cn } from "../utils/cn";

// ============================================================
// Логотип приложения: «лист + сигнал Wi-Fi»
// Скруглённый квадрат с агрозелёным градиентом и листом,
// в углу — янтарный значок беспроводной связи.
// ============================================================
export function Logo({
  size = "md",
  className,
}: {
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
}) {
  const dims = {
    sm: { box: "h-9 w-9", icon: "h-5 w-5", dot: "h-3.5 w-3.5", wifi: 9 },
    md: { box: "h-12 w-12", icon: "h-7 w-7", dot: "h-4 w-4", wifi: 11 },
    lg: { box: "h-16 w-16", icon: "h-9 w-9", dot: "h-5 w-5", wifi: 13 },
    xl: { box: "h-24 w-24", icon: "h-14 w-14", dot: "h-7 w-7", wifi: 18 },
  }[size];

  return (
    <div
      className={cn(
        "relative flex items-center justify-center rounded-[28%] bg-gradient-to-br from-brand-light to-brand-dark shadow-lg shadow-brand/40",
        dims.box,
        className
      )}
    >
      <Leaf className={cn("text-white", dims.icon)} strokeWidth={2.2} />
      {/* Значок Wi-Fi в углу */}
      <div
        className={cn(
          "absolute -bottom-1 -right-1 flex items-center justify-center rounded-full bg-amber ring-2 ring-bg",
          dims.dot
        )}
      >
        <WifiMark size={dims.wifi} />
      </div>
    </div>
  );
}

function WifiMark({ size }: { size: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path
        d="M5 12.5a10 10 0 0 1 14 0"
        stroke="#0F1B12"
        strokeWidth="2.5"
        strokeLinecap="round"
      />
      <path d="M8 16a5.5 5.5 0 0 1 8 0" stroke="#0F1B12" strokeWidth="2.5" strokeLinecap="round" />
      <circle cx="12" cy="19.5" r="1.5" fill="#0F1B12" />
    </svg>
  );
}
