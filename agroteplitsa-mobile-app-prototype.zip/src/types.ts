// ============================================================
// Типы данных приложения «АгроТеплица.Контроль»
// ============================================================

/** Ролевая модель пользователей */
export type Role = "agronomist" | "manager" | "tech";

/** Статус теплицы / системы */
export type Status = "ok" | "warning" | "critical";

/** Тип уведомления */
export type NotifyType = "critical" | "warning" | "info";

/** Фаза вегетации культуры */
export type Phase = "seeding" | "vegetation" | "flowering" | "fruiting";

/** Теплица / отделение */
export interface Greenhouse {
  id: string;
  name: string;
  culture: string;
  phase: Phase;
  status: Status;
  temp: number; // °C
  tempTarget: number; // °C
  humidity: number; // %
  light: number; // лк
  soil: number; // %
}

/** Точка временного ряда для графиков */
export interface ChartPoint {
  label: string;
  temp: number;
  humidity: number;
  target?: number;
}

/** Запись журнала внесения удобрений */
export interface FertilizerRecord {
  id: string;
  date: string;
  culture: string;
  type: string;
  dose: string;
  responsible: string;
}

/** Запись складского остатка */
export interface StockItem {
  id: string;
  name: string;
  type: string;
  balance: number; // кг
  capacity: number; // кг
  low: boolean;
}

/** Уведомление */
export interface Notification {
  id: string;
  type: NotifyType;
  title: string;
  body: string;
  time: string;
  source: string;
  read: boolean;
}

/** IoT-устройство */
export interface Device {
  id: string;
  name: string;
  type: string;
  location: string;
  status: "online" | "offline" | "warning";
  battery?: number;
  signal: number;
}

/** Камера видеонаблюдения */
export interface Camera {
  id: string;
  name: string;
  greenhouse: string;
  live: boolean;
  ai: string;
}

/** Роль пользователя (метаданные) */
export interface RoleInfo {
  id: Role;
  title: string;
  name: string;
  desc: string;
  initials: string;
}
